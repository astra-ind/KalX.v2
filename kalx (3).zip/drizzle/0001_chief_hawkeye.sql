CREATE TABLE `autoPilotJobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`jobType` enum('market_generation','market_resolution') NOT NULL,
	`status` enum('pending','running','completed','failed') NOT NULL DEFAULT 'pending',
	`result` json,
	`error` text,
	`executedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `autoPilotJobs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `comments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`marketId` int NOT NULL,
	`userId` int NOT NULL,
	`content` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `comments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `leaderboardSnapshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`rank` int NOT NULL,
	`portfolioValue` decimal(20,2) NOT NULL,
	`balance` decimal(20,2) NOT NULL,
	`positionValue` decimal(20,2) NOT NULL,
	`snapshotAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `leaderboardSnapshots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `markets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` text NOT NULL,
	`description` text,
	`category` varchar(50) NOT NULL,
	`type` enum('binary','multi') NOT NULL DEFAULT 'binary',
	`outcomes` json NOT NULL DEFAULT ('["YES","NO"]'),
	`liquidityParameter` decimal(20,8) NOT NULL DEFAULT '100',
	`shares` json NOT NULL DEFAULT ('{}'),
	`status` enum('active','resolved','cancelled') NOT NULL DEFAULT 'active',
	`resolvedOutcomeIndex` int,
	`expiresAt` timestamp NOT NULL,
	`volume` decimal(20,2) NOT NULL DEFAULT '0',
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `markets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `positions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`marketId` int NOT NULL,
	`outcomeIndex` int NOT NULL,
	`shares` decimal(20,8) NOT NULL DEFAULT '0',
	`avgEntryPrice` decimal(20,8) NOT NULL DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `positions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `priceHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`marketId` int NOT NULL,
	`outcomeIndex` int NOT NULL,
	`price` decimal(20,8) NOT NULL,
	`probability` decimal(5,4) NOT NULL,
	`timestamp` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `priceHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`marketId` int NOT NULL,
	`type` enum('BUY','SELL') NOT NULL,
	`outcomeIndex` int NOT NULL,
	`shares` decimal(20,8) NOT NULL,
	`pricePerShare` decimal(20,8) NOT NULL,
	`total` decimal(20,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `balance` decimal(20,2) DEFAULT '100000.00' NOT NULL;--> statement-breakpoint
CREATE INDEX `jobType_idx` ON `autoPilotJobs` (`jobType`);--> statement-breakpoint
CREATE INDEX `status_idx` ON `autoPilotJobs` (`status`);--> statement-breakpoint
CREATE INDEX `market_idx` ON `comments` (`marketId`);--> statement-breakpoint
CREATE INDEX `user_idx` ON `comments` (`userId`);--> statement-breakpoint
CREATE INDEX `user_idx` ON `leaderboardSnapshots` (`userId`);--> statement-breakpoint
CREATE INDEX `snapshot_idx` ON `leaderboardSnapshots` (`snapshotAt`);--> statement-breakpoint
CREATE INDEX `category_idx` ON `markets` (`category`);--> statement-breakpoint
CREATE INDEX `status_idx` ON `markets` (`status`);--> statement-breakpoint
CREATE INDEX `expiresAt_idx` ON `markets` (`expiresAt`);--> statement-breakpoint
CREATE INDEX `user_market_idx` ON `positions` (`userId`,`marketId`);--> statement-breakpoint
CREATE INDEX `market_idx` ON `priceHistory` (`marketId`);--> statement-breakpoint
CREATE INDEX `timestamp_idx` ON `priceHistory` (`timestamp`);--> statement-breakpoint
CREATE INDEX `user_idx` ON `transactions` (`userId`);--> statement-breakpoint
CREATE INDEX `market_idx` ON `transactions` (`marketId`);