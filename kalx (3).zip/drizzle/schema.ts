import { 
  int, 
  mysqlEnum, 
  mysqlTable, 
  text, 
  timestamp, 
  varchar,
  decimal,
  boolean,
  json,
  index
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  // Virtual sim token balance
  balance: decimal("balance", { precision: 20, scale: 2 }).default("100000.00").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Prediction markets table
 */
export const markets = mysqlTable("markets", {
  id: int("id").autoincrement().primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  category: varchar("category", { length: 50 }).notNull(), // Politics, Finance, Sports, Crypto, etc.
  type: mysqlEnum("type", ["binary", "multi"]).default("binary").notNull(),
  // For binary: YES/NO; for multi: JSON array of outcome names
  outcomes: json("outcomes").$type<string[]>().notNull().default(["YES", "NO"]),
  // LMSR liquidity parameter
  liquidityParameter: decimal("liquidityParameter", { precision: 20, scale: 8 }).default("100").notNull(),
  // Current share holdings for each outcome (stored as JSON for simplicity)
  shares: json("shares").$type<Record<number, number>>().notNull().default({}),
  // Market status
  status: mysqlEnum("status", ["active", "resolved", "cancelled"]).default("active").notNull(),
  // Resolved outcome index (null if not resolved)
  resolvedOutcomeIndex: int("resolvedOutcomeIndex"),
  // Expiration date
  expiresAt: timestamp("expiresAt").notNull(),
  // Total volume traded
  volume: decimal("volume", { precision: 20, scale: 2 }).default("0").notNull(),
  // Created by (user ID)
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  categoryIdx: index("category_idx").on(table.category),
  statusIdx: index("status_idx").on(table.status),
  expiresAtIdx: index("expiresAt_idx").on(table.expiresAt),
}));

export type Market = typeof markets.$inferSelect;
export type InsertMarket = typeof markets.$inferInsert;

/**
 * User positions: tracks how many shares of each outcome a user holds
 */
export const positions = mysqlTable("positions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  marketId: int("marketId").notNull(),
  // Outcome index (0 for YES/NO binary, 0-N for multi)
  outcomeIndex: int("outcomeIndex").notNull(),
  // Number of shares held
  shares: decimal("shares", { precision: 20, scale: 8 }).default("0").notNull(),
  // Average entry price (for P&L calculation)
  avgEntryPrice: decimal("avgEntryPrice", { precision: 20, scale: 8 }).default("0").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userMarketIdx: index("user_market_idx").on(table.userId, table.marketId),
}));

export type Position = typeof positions.$inferSelect;
export type InsertPosition = typeof positions.$inferInsert;

/**
 * Transaction history: all buy/sell trades
 */
export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  marketId: int("marketId").notNull(),
  // BUY or SELL
  type: mysqlEnum("type", ["BUY", "SELL"]).notNull(),
  // Outcome index
  outcomeIndex: int("outcomeIndex").notNull(),
  // Number of shares traded
  shares: decimal("shares", { precision: 20, scale: 8 }).notNull(),
  // Price per share at time of trade
  pricePerShare: decimal("pricePerShare", { precision: 20, scale: 8 }).notNull(),
  // Total cost/proceeds
  total: decimal("total", { precision: 20, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdx: index("user_idx").on(table.userId),
  marketIdx: index("market_idx").on(table.marketId),
}));

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

/**
 * Price history: snapshots of market prices over time for charting
 */
export const priceHistory = mysqlTable("priceHistory", {
  id: int("id").autoincrement().primaryKey(),
  marketId: int("marketId").notNull(),
  // Outcome index
  outcomeIndex: int("outcomeIndex").notNull(),
  // Price at this timestamp
  price: decimal("price", { precision: 20, scale: 8 }).notNull(),
  // Probability (price / 100 for binary)
  probability: decimal("probability", { precision: 5, scale: 4 }).notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
}, (table) => ({
  marketIdx: index("market_idx").on(table.marketId),
  timestampIdx: index("timestamp_idx").on(table.timestamp),
}));

export type PriceHistory = typeof priceHistory.$inferSelect;
export type InsertPriceHistory = typeof priceHistory.$inferInsert;

/**
 * Comments on markets for social discussion
 */
export const comments = mysqlTable("comments", {
  id: int("id").autoincrement().primaryKey(),
  marketId: int("marketId").notNull(),
  userId: int("userId").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  marketIdx: index("market_idx").on(table.marketId),
  userIdx: index("user_idx").on(table.userId),
}));

export type Comment = typeof comments.$inferSelect;
export type InsertComment = typeof comments.$inferInsert;

/**
 * Leaderboard snapshots: cached user rankings by portfolio value
 */
export const leaderboardSnapshots = mysqlTable("leaderboardSnapshots", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  rank: int("rank").notNull(),
  portfolioValue: decimal("portfolioValue", { precision: 20, scale: 2 }).notNull(),
  balance: decimal("balance", { precision: 20, scale: 2 }).notNull(),
  positionValue: decimal("positionValue", { precision: 20, scale: 2 }).notNull(),
  snapshotAt: timestamp("snapshotAt").defaultNow().notNull(),
}, (table) => ({
  userIdx: index("user_idx").on(table.userId),
  snapshotIdx: index("snapshot_idx").on(table.snapshotAt),
}));

export type LeaderboardSnapshot = typeof leaderboardSnapshots.$inferSelect;
export type InsertLeaderboardSnapshot = typeof leaderboardSnapshots.$inferInsert;

/**
 * AI AutoPilot job tracking
 */
export const autoPilotJobs = mysqlTable("autoPilotJobs", {
  id: int("id").autoincrement().primaryKey(),
  jobType: mysqlEnum("jobType", ["market_generation", "market_resolution"]).notNull(),
  status: mysqlEnum("status", ["pending", "running", "completed", "failed"]).default("pending").notNull(),
  result: json("result").$type<Record<string, unknown>>(),
  error: text("error"),
  executedAt: timestamp("executedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  jobTypeIdx: index("jobType_idx").on(table.jobType),
  statusIdx: index("status_idx").on(table.status),
}));

export type AutoPilotJob = typeof autoPilotJobs.$inferSelect;
export type InsertAutoPilotJob = typeof autoPilotJobs.$inferInsert;
