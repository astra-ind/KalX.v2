import { Newspaper } from "lucide-react";

interface NewsSourceBadgeProps {
  source?: string;
  date?: Date;
}

export default function NewsSourceBadge({ source, date }: NewsSourceBadgeProps) {
  if (!source) return null;

  return (
    <div className="flex items-center gap-1 px-2 py-1 bg-blue-500/10 border border-blue-500/20 rounded text-xs">
      <Newspaper className="w-3 h-3 text-blue-400" />
      <span className="text-blue-300">{source}</span>
      {date && (
        <span className="text-blue-200/60">
          {new Date(date).toLocaleDateString()}
        </span>
      )}
    </div>
  );
}
