import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { Menu, X, LogOut, Wallet, TrendingUp } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import ConnectionStatus from "./ConnectionStatus";

interface MainLayoutProps {
  children: React.ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const { user, isAuthenticated, logout, loading } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Top Navigation */}
      <nav className="border-b slate-700 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 font-bold text-xl text-accent hover:text-accent/80 transition-colors">
            <TrendingUp className="w-6 h-6" />
            <span>KalX</span>
          </Link>

          {/* Connection Status */}
          <ConnectionStatus />

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Markets
            </Link>
            <Link href="/leaderboard" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Leaderboard
            </Link>
            {isAuthenticated && (
              <>
                <Link href="/profile" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                  Portfolio
                </Link>
                {user?.role === "admin" && (
                  <Link href="/admin" className="text-sm font-medium text-accent hover:text-accent/80 transition-colors">
                    Admin
                  </Link>
                )}
              </>
            )}
          </div>

          {/* Right Section */}
          <div className="hidden md:flex items-center gap-4">
            {isAuthenticated && user ? (
              <>
                <div className="flex items-center gap-2 px-3 py-1 bg-muted/30 rounded-lg">
                  <Wallet className="w-4 h-4 text-accent" />
                  <span className="text-sm font-medium">
                    ${(Math.random() * 100000).toFixed(2)}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">{user.name}</span>
                  <button
                    onClick={handleLogout}
                    className="p-2 hover:bg-muted rounded-lg transition-colors"
                    title="Logout"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              </>
            ) : !loading ? (
              <Button
                onClick={() => startLogin()}
                className="bg-accent hover:bg-accent/90 text-accent-foreground"
              >
                Sign In
              </Button>
            ) : null}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 hover:bg-muted rounded-lg transition-colors"
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t slate-700 bg-card/80 backdrop-blur-sm">
            <div className="container py-4 flex flex-col gap-3">
              <Link href="/">
                <a
                  className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Markets
                </a>
              </Link>
              <Link href="/leaderboard">
                <a
                  className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Leaderboard
                </a>
              </Link>
              {isAuthenticated && (
                <Link href="/profile">
                  <a
                    className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Portfolio
                  </a>
                </Link>
              )}
              <div className="pt-3 border-t slate-700">
                {isAuthenticated && user ? (
                  <>
                    <div className="flex items-center gap-2 px-3 py-2 bg-muted/30 rounded-lg mb-3">
                      <Wallet className="w-4 h-4 text-accent" />
                      <span className="text-sm font-medium">
                        ${(Math.random() * 100000).toFixed(2)}
                      </span>
                    </div>
                    <Button
                      onClick={handleLogout}
                      variant="outline"
                      className="w-full"
                    >
                      <LogOut className="w-4 h-4 mr-2" />
                      Logout
                    </Button>
                  </>
                ) : !loading ? (
                  <Button
                    onClick={() => {
                      startLogin();
                      setMobileMenuOpen(false);
                    }}
                    className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                  >
                    Sign In
                  </Button>
                ) : null}
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main>{children}</main>
    </div>
  );
}
