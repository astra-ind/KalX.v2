import { Link } from "wouter";
import { TrendingUp, Share2, MessageCircle } from "lucide-react";

interface MarketCardPremiumProps {
  id: number;
  title: string;
  category: string;
  yesPrice: number;
  noPrice: number;
  volume: number;
  expiresAt: Date;
  commentCount?: number;
}

export default function MarketCardPremium({
  id,
  title,
  category,
  yesPrice,
  noPrice,
  volume,
  expiresAt,
  commentCount = 0,
}: MarketCardPremiumProps) {
  const daysUntilExpiry = Math.ceil(
    (expiresAt.getTime() - Date.now()) / (1000 * 60 * 60 * 24)
  );

  const handleShare = (e: React.MouseEvent) => {
    e.preventDefault();
    const shareText = `Check out this prediction market: "${title}" on KalX. Current odds: YES ${(yesPrice * 100).toFixed(1)}% vs NO ${(noPrice * 100).toFixed(1)}%`;
    const shareUrl = `${window.location.origin}/market/${id}`;

    if (navigator.share) {
      navigator.share({
        title: "KalX Prediction Market",
        text: shareText,
        url: shareUrl,
      });
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
      alert("Market link copied to clipboard!");
    }
  };

  return (
    <Link href={`/market/${id}`}>
      <a className="market-card group cursor-pointer">
        {/* Header with Category Badge */}
        <div className="flex items-start justify-between mb-4">
          <span className="badge-premium">{category}</span>
          <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={handleShare}
              className="p-2 rounded-lg bg-primary/10 hover:bg-primary/20 transition-colors"
              title="Share market"
            >
              <Share2 className="w-4 h-4 text-primary" />
            </button>
            <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-muted/10 text-xs text-muted-foreground">
              <MessageCircle className="w-3 h-3" />
              {commentCount}
            </div>
          </div>
        </div>

        {/* Title */}
        <h3 className="text-lg font-bold mb-4 line-clamp-2 group-hover:text-primary transition-colors">
          {title}
        </h3>

        {/* Probability Bars */}
        <div className="space-y-3 mb-6">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-green-400">YES</span>
              <span className="text-sm font-bold text-green-400">
                {(yesPrice * 100).toFixed(1)}¢
              </span>
            </div>
            <div className="h-2 bg-card rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-green-500 to-green-400 rounded-full transition-all duration-300"
                style={{ width: `${yesPrice * 100}%` }}
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-red-400">NO</span>
              <span className="text-sm font-bold text-red-400">
                {(noPrice * 100).toFixed(1)}¢
              </span>
            </div>
            <div className="h-2 bg-card rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-red-500 to-red-400 rounded-full transition-all duration-300"
                style={{ width: `${noPrice * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Stats Footer */}
        <div className="gradient-divider mb-4" />
        <div className="grid grid-cols-3 gap-2 text-xs">
          <div>
            <p className="text-muted-foreground mb-1">Volume</p>
            <p className="font-bold text-foreground">
              ${(volume / 1000000).toFixed(1)}M
            </p>
          </div>
          <div>
            <p className="text-muted-foreground mb-1">Expires</p>
            <p className="font-bold text-foreground">{daysUntilExpiry}d</p>
          </div>
          <div>
            <p className="text-muted-foreground mb-1">Probability</p>
            <div className="flex items-center gap-1">
              <TrendingUp className="w-3 h-3 text-primary" />
              <p className="font-bold text-primary">
                {(yesPrice * 100).toFixed(0)}%
              </p>
            </div>
          </div>
        </div>

        {/* Hover Glow Effect */}
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none rounded-xl" />
      </a>
    </Link>
  );
}
