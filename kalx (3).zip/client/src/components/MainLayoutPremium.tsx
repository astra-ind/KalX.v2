import { useAuth } from "@/_core/hooks/useAuth";
import { Link, useLocation } from "wouter";
import { Menu, X, LogOut, Home, Wallet, TrendingUp, Settings, BarChart3, Shield } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { startLogin } from "@/const";

interface MainLayoutPremiumProps {
  children: React.ReactNode;
}

export default function MainLayoutPremium({ children }: MainLayoutPremiumProps) {
  const { user, isAuthenticated, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();

  const isActive = (path: string) => location === path;

  const navItems = [
    { href: "/", label: "Markets", icon: Home },
    { href: "/leaderboard", label: "Leaderboard", icon: TrendingUp },
    ...(isAuthenticated ? [{ href: "/portfolio", label: "Portfolio", icon: Wallet }] : []),
    ...(user?.role === "admin" ? [{ href: "/admin", label: "Admin", icon: Shield }] : []),
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-blue-950/20">
      {/* Premium Header */}
      <header className="sticky top-0 z-50 backdrop-blur-md border-b border-slate-700/50 bg-background/80">
        <nav className="container flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/">
            <a className="flex items-center gap-3 group">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center transform group-hover:scale-110 transition-transform">
                <span className="font-bold text-white text-lg">K</span>
              </div>
              <span className="text-2xl font-bold font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                KalX
              </span>
            </a>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map(({ href, label, icon: Icon }) => (
              <Link key={href} href={href}>
                <a
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                    isActive(href)
                      ? "bg-primary/20 text-primary border border-primary/50"
                      : "text-muted-foreground hover:text-foreground hover:bg-card/50"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{label}</span>
                </a>
              </Link>
            ))}
          </div>

          {/* Right Section */}
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <div className="hidden md:flex items-center gap-3">
                <div className="px-4 py-2 rounded-lg bg-card/50 border border-slate-700/50">
                  <p className="text-sm text-muted-foreground">Balance</p>
                  <p className="font-bold text-primary">$100,000</p>
                </div>
                <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-card/50 border border-slate-700/50">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                    <span className="text-xs font-bold text-white">{user?.name?.[0]?.toUpperCase()}</span>
                  </div>
                  <span className="text-sm font-medium text-foreground">{user?.name}</span>
                </div>
                <button
                  onClick={() => logout()}
                  className="p-2 rounded-lg hover:bg-card/50 transition-colors text-muted-foreground hover:text-foreground"
                  title="Logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <Button
                onClick={() => startLogin()}
                className="hidden md:inline-flex bg-gradient-to-r from-primary to-secondary hover:shadow-lg hover:shadow-primary/50 transition-all"
              >
                Sign In
              </Button>
            )}

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-card/50 transition-colors"
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </nav>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-slate-700/50 bg-background/95 backdrop-blur-sm animate-slideInLeft">
            <div className="container py-4 space-y-2">
              {navItems.map(({ href, label, icon: Icon }) => (
                <Link key={href} href={href}>
                  <a
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                      isActive(href)
                        ? "bg-primary/20 text-primary"
                        : "text-muted-foreground hover:text-foreground hover:bg-card/50"
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{label}</span>
                  </a>
                </Link>
              ))}
              {isAuthenticated && (
                <button
                  onClick={() => {
                    logout();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-muted-foreground hover:text-foreground hover:bg-card/50 transition-all"
                >
                  <LogOut className="w-5 h-5" />
                  <span className="font-medium">Logout</span>
                </button>
              )}
              {!isAuthenticated && (
                <button
                  onClick={() => {
                    startLogin();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full px-4 py-3 rounded-lg bg-gradient-to-r from-primary to-secondary text-white font-medium transition-all hover:shadow-lg"
                >
                  Sign In
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="container py-8 animate-fadeInUp">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-700/50 bg-background/50 backdrop-blur-sm mt-20">
        <div className="container py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-foreground mb-4">KalX</h3>
              <p className="text-sm text-muted-foreground">
                The next-generation prediction market platform. Trade on real-world outcomes with virtual tokens.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="/" className="hover:text-primary transition-colors">Markets</a></li>
                <li><a href="/leaderboard" className="hover:text-primary transition-colors">Leaderboard</a></li>
                <li><a href="/portfolio" className="hover:text-primary transition-colors">Portfolio</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Resources</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Docs</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">FAQ</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Support</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Terms</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Privacy</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Cookies</a></li>
              </ul>
            </div>
          </div>
          <div className="gradient-divider mb-6" />
          <div className="flex flex-col md:flex-row items-center justify-between text-sm text-muted-foreground">
            <p>&copy; 2026 KalX. All rights reserved.</p>
            <p>Powered by Manus • Prediction Markets</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
