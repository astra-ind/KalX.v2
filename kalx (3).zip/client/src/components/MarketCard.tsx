import { TrendingUp, TrendingDown, MessageCircle, Volume2 } from "lucide-react";
import { Link } from "wouter";
import NewsSourceBadge from "./NewsSourceBadge";

interface MarketCardProps {
  market: any;
}

export default function MarketCard({ market }: MarketCardProps) {
  const { id, title, category, outcomes, volume, expiresAt, shares } = market;
  
  // Calculate probability from shares
  let probability = 0.5;
  if (shares && typeof shares === 'object') {
    const yesShares = shares.YES || 0;
    const noShares = shares.NO || 0;
    const total = yesShares + noShares;
    if (total > 0) {
      probability = yesShares / total;
    }
  }
  
  const commentCount = 0;
  const expiryDate = new Date(expiresAt);
  const daysUntilExpiry = Math.ceil(
    (expiryDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24)
  );
  const isExpired = daysUntilExpiry <= 0;

  // Format volume
  const formatVolume = (vol: number) => {
    if (vol >= 1000000) return `$${(vol / 1000000).toFixed(1)}M`;
    if (vol >= 1000) return `$${(vol / 1000).toFixed(1)}K`;
    return `$${vol}`;
  };

  // Determine color based on probability
  const getColorClass = (prob: number) => {
    if (prob > 0.7) return "text-green-500";
    if (prob < 0.3) return "text-red-500";
    return "text-yellow-500";
  };

  return (
    <Link href={`/market/${id}`} className="market-card group">
        <div className="space-y-3">
          {/* Header */}
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-sm sm:text-base text-foreground group-hover:text-accent transition-colors line-clamp-2">
                {title}
              </h3>
              <p className="text-xs text-muted-foreground mt-1">{category}</p>
            </div>
            <div className="flex-shrink-0 text-right">
              <div className={`text-lg sm:text-xl font-bold ${outcomes && outcomes.length > 2 ? 'text-blue-500' : getColorClass(probability)}`}>
                {outcomes && outcomes.length > 2 ? `${outcomes.length}` : `${(probability * 100).toFixed(0)}%`}
              </div>
              <p className="text-xs text-muted-foreground">{outcomes && outcomes.length > 2 ? 'Outcomes' : outcomes?.[0]}</p>
            </div>
          </div>

          {/* News Source */}
          {market.newsSource && (
            <NewsSourceBadge source={market.newsSource} date={market.newsDate} />
          )}

          {/* Outcomes */}
          <div className={`grid ${outcomes && outcomes.length > 2 ? 'grid-cols-2' : 'grid-cols-2'} gap-2`}>
            {outcomes && outcomes.map((outcome: string, idx: number) => {
              let outcomeProb = 0.5;
              if (shares && typeof shares === 'object') {
                const outcomeShares = (shares as any)[outcome] || 0;
                const totalShares = Object.values(shares).reduce((sum: number, val: any) => sum + (val || 0), 0);
                outcomeProb = totalShares > 0 ? outcomeShares / totalShares : 1 / (outcomes?.length || 2);
              }
              return (
                <div
                  key={idx}
                  className="flex items-center justify-between px-2 py-1.5 bg-muted/20 rounded text-xs"
                >
                  <span className="text-muted-foreground truncate">{outcome}</span>
                  <span className="font-semibold text-foreground ml-1">
                    {(outcomeProb * 100).toFixed(0)}%
                  </span>
                </div>
              );
            })}
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-700/50">
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <div className="flex items-center gap-1">
                <Volume2 className="w-3 h-3" />
                <span>{formatVolume(volume)}</span>
              </div>
              {commentCount > 0 && (
                <div className="flex items-center gap-1">
                  <MessageCircle className="w-3 h-3" />
                  <span>{commentCount}</span>
                </div>
              )}
            </div>
            <div
              className={`text-xs font-medium ${
                isExpired
                  ? "text-red-500"
                  : daysUntilExpiry <= 7
                    ? "text-yellow-500"
                    : "text-green-500"
              }`}
            >
              {isExpired ? "Expired" : `${daysUntilExpiry}d`}
            </div>
          </div>
        </div>
    </Link>
  );
}
