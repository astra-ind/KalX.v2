import { X } from "lucide-react";

const CATEGORIES = [
  "All",
  "Politics",
  "Finance",
  "Sports",
  "Crypto",
  "Technology",
  "Entertainment",
  "Other",
];

interface CategoryFilterProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

export default function CategoryFilter({
  selectedCategory,
  onCategoryChange,
}: CategoryFilterProps) {
  return (
    <div className="flex flex-wrap gap-2">
      {CATEGORIES.map((category) => (
        <button
          key={category}
          onClick={() => onCategoryChange(category === "All" ? "" : category)}
          className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
            (category === "All" && selectedCategory === "") ||
            selectedCategory === category
              ? "bg-accent text-accent-foreground"
              : "bg-muted/30 text-muted-foreground hover:bg-muted/50"
          }`}
        >
          {category}
        </button>
      ))}
    </div>
  );
}
