import { useState } from "react";
import MainLayout from "@/components/MainLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui/spinner";
import { ArrowLeft, Shield, User } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

export default function UserManagement() {
  const { isAuthenticated, user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  // Mock users data
  const mockUsers = [
    {
      id: 1,
      name: "John Doe",
      email: "john@example.com",
      role: "admin",
      balance: 100000,
      createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
      portfolioValue: 125000,
    },
    {
      id: 2,
      name: "Jane Smith",
      email: "jane@example.com",
      role: "user",
      balance: 95000,
      createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000),
      portfolioValue: 110000,
    },
    {
      id: 3,
      name: "Bob Johnson",
      email: "bob@example.com",
      role: "user",
      balance: 85000,
      createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
      portfolioValue: 92000,
    },
    {
      id: 4,
      name: "Alice Williams",
      email: "alice@example.com",
      role: "user",
      balance: 100000,
      createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      portfolioValue: 105000,
    },
  ];

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <MainLayout>
        <div className="container py-12 text-center">
          <p className="text-muted-foreground mb-4">
            Access denied. Admin privileges required.
          </p>
          <Link href="/">
            <a className="text-accent hover:text-accent/80">Back to Markets</a>
          </Link>
        </div>
      </MainLayout>
    );
  }

  const filteredUsers = mockUsers.filter((u) =>
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <MainLayout>
      <div className="container py-8">
        {/* Back Button */}
        <Link href="/admin">
          <a className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back to Admin Dashboard
          </a>
        </Link>

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">User Management</h1>
          <p className="text-muted-foreground">
            Manage KalX users and their roles
          </p>
        </div>

        {/* Search */}
        <div className="mb-6">
          <input
            type="text"
            placeholder="Search users by name or email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-2 bg-card rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
            style={{ border: "1px solid hsl(var(--border))" }}
          />
        </div>

        {/* Users Table */}
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr
                  className="border-b"
                  style={{ borderColor: "hsl(var(--border))" }}
                >
                  <th className="text-left py-3 px-4 font-semibold">Name</th>
                  <th className="text-left py-3 px-4 font-semibold">Email</th>
                  <th className="text-left py-3 px-4 font-semibold">Role</th>
                  <th className="text-right py-3 px-4 font-semibold">Balance</th>
                  <th className="text-right py-3 px-4 font-semibold">
                    Portfolio Value
                  </th>
                  <th className="text-left py-3 px-4 font-semibold">
                    Joined
                  </th>
                  <th className="text-left py-3 px-4 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map((u) => (
                  <tr
                    key={u.id}
                    className="border-b hover:bg-card/50 transition-colors"
                    style={{ borderColor: "hsl(var(--border))" }}
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center">
                          <User className="w-4 h-4 text-accent" />
                        </div>
                        <span className="font-medium">{u.name}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-muted-foreground">
                      {u.email}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-semibold ${
                          u.role === "admin"
                            ? "bg-accent/20 text-accent"
                            : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {u.role === "admin" && (
                          <Shield className="w-3 h-3" />
                        )}
                        {u.role.charAt(0).toUpperCase() + u.role.slice(1)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-medium">
                      ${u.balance.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right font-medium">
                      ${u.portfolioValue.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-muted-foreground text-xs">
                      {u.createdAt.toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        {u.role === "user" ? (
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-xs"
                          >
                            Make Admin
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-xs"
                          >
                            Remove Admin
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
          <Card className="p-6">
            <p className="text-sm text-muted-foreground mb-2">Total Users</p>
            <p className="text-3xl font-bold">{mockUsers.length}</p>
          </Card>
          <Card className="p-6">
            <p className="text-sm text-muted-foreground mb-2">Admins</p>
            <p className="text-3xl font-bold">
              {mockUsers.filter((u) => u.role === "admin").length}
            </p>
          </Card>
          <Card className="p-6">
            <p className="text-sm text-muted-foreground mb-2">
              Total Portfolio Value
            </p>
            <p className="text-3xl font-bold">
              ${mockUsers.reduce((sum, u) => sum + u.portfolioValue, 0).toLocaleString()}
            </p>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
}
