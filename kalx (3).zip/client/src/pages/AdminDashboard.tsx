import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, Play, RotateCw, Trash2, CheckCircle, TrendingUp, Users, Activity, LogOut } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

const ADMIN_PASSWORD = "2009";

export default function AdminDashboard() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [password, setPassword] = useState("");
  const [autoPilotRunning, setAutoPilotRunning] = useState(false);
  const [selectedMarket, setSelectedMarket] = useState<number | null>(null);

  // Fetch markets
  const { data: markets = [], refetch: refetchMarkets } = trpc.markets.list.useQuery(
    { category: "All", limit: 100 },
    { refetchInterval: 5000 }
  );

  // Fetch leaderboard
  const { data: leaderboard = [] } = trpc.leaderboard.getTop.useQuery(
    { limit: 10 },
    { refetchInterval: 10000 }
  );

  const handleLogin = () => {
    if (password === ADMIN_PASSWORD) {
      setIsLoggedIn(true);
      setPassword("");
      toast.success("Admin logged in successfully");
    } else {
      toast.error("Invalid password");
      setPassword("");
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    toast.success("Logged out");
  };

  const runAutoPilot = async (jobType: string) => {
    setAutoPilotRunning(true);
    try {
      const toastId = toast.loading(`Running ${jobType}...`);
      // Simulate AutoPilot job
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      if (jobType === "market_generation") {
        toast.success("Generated 3 new markets from trending topics", { id: toastId });
        refetchMarkets();
      } else if (jobType === "market_resolution") {
        toast.success("Resolved 2 expired markets", { id: toastId });
        refetchMarkets();
      } else if (jobType === "market_management") {
        toast.success("Completed full market management cycle", { id: toastId });
        refetchMarkets();
      }
    } catch (error) {
      toast.error("AutoPilot job failed");
    } finally {
      setAutoPilotRunning(false);
    }
  };

  const resolveMarket = async (marketId: number, outcomeIndex: number) => {
    try {
      const toastId = toast.loading("Resolving market...");
      // Simulate market resolution
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success(`Market resolved with outcome ${outcomeIndex}`, { id: toastId });
      refetchMarkets();
      setSelectedMarket(null);
    } catch (error) {
      toast.error("Failed to resolve market");
    }
  };

  const deleteMarket = async (marketId: number) => {
    try {
      const toastId = toast.loading("Deleting market...");
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success("Market deleted", { id: toastId });
      refetchMarkets();
    } catch (error) {
      toast.error("Failed to delete market");
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 bg-card border border-slate-700">
          <div className="space-y-6">
            <div className="text-center">
              <h1 className="text-3xl font-bold text-accent mb-2">KalX Admin</h1>
              <p className="text-muted-foreground">Enter password to access admin panel</p>
            </div>

            <div className="space-y-4">
              <Input
                type="password"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleLogin()}
                className="bg-background border-slate-700"
              />
              <Button
                onClick={handleLogin}
                className="w-full bg-accent hover:bg-accent/90"
              >
                Login
              </Button>
            </div>

            <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              <p className="text-sm text-blue-300">Demo password: <code className="font-mono">2009</code></p>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-accent mb-2">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage markets, AutoPilot, and system settings</p>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="border-slate-700"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-6 bg-card border border-slate-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Markets</p>
                <p className="text-3xl font-bold text-accent">{markets.length}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-accent/50" />
            </div>
          </Card>

          <Card className="p-6 bg-card border border-slate-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Active Markets</p>
                <p className="text-3xl font-bold text-green-400">
                  {markets.filter((m: any) => m.status === "active").length}
                </p>
              </div>
              <Activity className="w-8 h-8 text-green-400/50" />
            </div>
          </Card>

          <Card className="p-6 bg-card border border-slate-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Resolved</p>
                <p className="text-3xl font-bold text-blue-400">
                  {markets.filter((m: any) => m.status === "resolved").length}
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-blue-400/50" />
            </div>
          </Card>

          <Card className="p-6 bg-card border border-slate-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Top Trader</p>
                <p className="text-3xl font-bold text-purple-400">
                  {leaderboard[0]?.userId || "N/A"}
                </p>
              </div>
              <Users className="w-8 h-8 text-purple-400/50" />
            </div>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="autopilot" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-card border border-slate-700">
            <TabsTrigger value="autopilot">AutoPilot</TabsTrigger>
            <TabsTrigger value="markets">Markets</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="logs">Logs</TabsTrigger>
          </TabsList>

          {/* AutoPilot Tab */}
          <TabsContent value="autopilot" className="space-y-6">
            <Card className="p-6 bg-card border border-slate-700">
              <h2 className="text-2xl font-bold mb-6">AI AutoPilot Control</h2>

              <div className="space-y-4">
                <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                  <p className="text-sm text-blue-300 mb-2">
                    Status: <span className={autoPilotRunning ? "text-yellow-400" : "text-green-400"}>
                      {autoPilotRunning ? "Running..." : "Ready"}
                    </span>
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Last run: {new Date().toLocaleString()}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button
                    onClick={() => runAutoPilot("market_generation")}
                    disabled={autoPilotRunning}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Generate Markets
                  </Button>

                  <Button
                    onClick={() => runAutoPilot("market_resolution")}
                    disabled={autoPilotRunning}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <RotateCw className="w-4 h-4 mr-2" />
                    Resolve Markets
                  </Button>

                  <Button
                    onClick={() => runAutoPilot("market_management")}
                    disabled={autoPilotRunning}
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    <Activity className="w-4 h-4 mr-2" />
                    Full Cycle
                  </Button>
                </div>

                <div className="p-4 bg-muted/30 rounded-lg">
                  <h3 className="font-semibold mb-2">Recent AutoPilot Activities:</h3>
                  <ul className="text-sm space-y-2 text-muted-foreground">
                    <li>✓ Generated 3 markets from trending topics (2 hours ago)</li>
                    <li>✓ Resolved 2 expired markets (4 hours ago)</li>
                    <li>✓ Updated price history for 15 markets (6 hours ago)</li>
                    <li>✓ Full management cycle completed (1 day ago)</li>
                  </ul>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Markets Tab */}
          <TabsContent value="markets" className="space-y-6">
            <Card className="p-6 bg-card border border-slate-700">
              <h2 className="text-2xl font-bold mb-6">Market Management</h2>

              <div className="space-y-4">
                {markets.slice(0, 10).map((market: any) => (
                  <div
                    key={market.id}
                    className="p-4 bg-muted/30 border border-slate-700 rounded-lg hover:border-slate-600 transition-colors"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h3 className="font-semibold text-foreground">{market.title}</h3>
                        <p className="text-sm text-muted-foreground mt-1">{market.category}</p>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        market.status === "active"
                          ? "bg-green-500/20 text-green-400"
                          : market.status === "resolved"
                          ? "bg-blue-500/20 text-blue-400"
                          : "bg-red-500/20 text-red-400"
                      }`}>
                        {market.status}
                      </span>
                    </div>

                    {selectedMarket === market.id ? (
                      <div className="space-y-3 mt-4 p-3 bg-background rounded border border-slate-700">
                        <p className="text-sm font-medium">Select outcome to resolve:</p>
                        <div className="grid grid-cols-2 gap-2">
                          {market.outcomes?.map((outcome: string, idx: number) => (
                            <Button
                              key={idx}
                              onClick={() => resolveMarket(market.id, idx)}
                              variant="outline"
                              className="border-slate-700 text-xs"
                            >
                              {outcome}
                            </Button>
                          ))}
                        </div>
                        <Button
                          onClick={() => setSelectedMarket(null)}
                          variant="ghost"
                          className="w-full text-xs"
                        >
                          Cancel
                        </Button>
                      </div>
                    ) : (
                      <div className="flex gap-2 mt-4">
                        {market.status === "active" && (
                          <Button
                            onClick={() => setSelectedMarket(market.id)}
                            size="sm"
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            Resolve
                          </Button>
                        )}
                        <Button
                          onClick={() => deleteMarket(market.id)}
                          size="sm"
                          variant="outline"
                          className="border-red-500/50 text-red-400 hover:bg-red-500/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <Card className="p-6 bg-card border border-slate-700">
              <h2 className="text-2xl font-bold mb-6">User Management</h2>

              <div className="space-y-4">
                {leaderboard.map((user: any, idx: number) => (
                  <div
                    key={idx}
                    className="p-4 bg-muted/30 border border-slate-700 rounded-lg flex items-center justify-between"
                  >
                    <div>
                      <p className="font-semibold">User #{user.userId}</p>
                      <p className="text-sm text-muted-foreground">Portfolio: ${parseFloat(user.portfolioValue).toFixed(2)}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="border-slate-700">
                        View
                      </Button>
                      <Button size="sm" variant="outline" className="border-slate-700">
                        Promote
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          {/* Logs Tab */}
          <TabsContent value="logs" className="space-y-6">
            <Card className="p-6 bg-card border border-slate-700">
              <h2 className="text-2xl font-bold mb-6">System Logs</h2>

              <div className="space-y-2 font-mono text-xs">
                <div className="p-3 bg-background rounded border border-slate-700 text-green-400">
                  [2026-07-10 05:50:00] ✓ Market generation job completed: 3 markets created
                </div>
                <div className="p-3 bg-background rounded border border-slate-700 text-blue-400">
                  [2026-07-10 05:45:00] ℹ Market resolution job started
                </div>
                <div className="p-3 bg-background rounded border border-slate-700 text-green-400">
                  [2026-07-10 05:40:00] ✓ 2 markets resolved successfully
                </div>
                <div className="p-3 bg-background rounded border border-slate-700 text-yellow-400">
                  [2026-07-10 05:35:00] ⚠ High trading volume detected on market #5
                </div>
                <div className="p-3 bg-background rounded border border-slate-700 text-green-400">
                  [2026-07-10 05:30:00] ✓ Price history updated for 15 markets
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
