import MainLayout from "@/components/MainLayout";
import { Card } from "@/components/ui/card";
import { Spinner } from "@/components/ui/spinner";
import { Medal, TrendingUp, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";

export default function Leaderboard() {
  const { data: leaderboard, isLoading } = trpc.leaderboard.getTop.useQuery({
    limit: 100,
  });

  // Mock leaderboard data
  const mockLeaderboard = [
    {
      rank: 1,
      userId: 1,
      userName: "CryptoWhale",
      portfolioValue: 245680.5,
      balance: 45230.5,
      positionValue: 200450,
      pnl: 45680.5,
    },
    {
      rank: 2,
      userId: 2,
      userName: "PredictionMaster",
      portfolioValue: 198765.32,
      balance: 35420.12,
      positionValue: 163345.2,
      pnl: 48765.32,
    },
    {
      rank: 3,
      userId: 3,
      userName: "MarketNinja",
      portfolioValue: 156234.75,
      balance: 28900.5,
      positionValue: 127334.25,
      pnl: 36234.75,
    },
    {
      rank: 4,
      userId: 4,
      userName: "TrendTrader",
      portfolioValue: 134567.89,
      balance: 22100.89,
      positionValue: 112467,
      pnl: 34567.89,
    },
    {
      rank: 5,
      userId: 5,
      userName: "VolatilityHunter",
      portfolioValue: 98765.32,
      balance: 18765.32,
      positionValue: 80000,
      pnl: -1234.68,
    },
    {
      rank: 6,
      userId: 6,
      userName: "DataDrivenDave",
      portfolioValue: 87654.21,
      balance: 15234.21,
      positionValue: 72420,
      pnl: 12654.21,
    },
    {
      rank: 7,
      userId: 7,
      userName: "NewsWatcher",
      portfolioValue: 76543.1,
      balance: 12543.1,
      positionValue: 64000,
      pnl: 8543.1,
    },
    {
      rank: 8,
      userId: 8,
      userName: "RiskTaker",
      portfolioValue: 65432.99,
      balance: 10432.99,
      positionValue: 55000,
      pnl: 5432.99,
    },
    {
      rank: 9,
      userId: 9,
      userName: "SteadyGains",
      portfolioValue: 54321.88,
      balance: 8321.88,
      positionValue: 46000,
      pnl: 4321.88,
    },
    {
      rank: 10,
      userId: 10,
      userName: "NewTrader",
      portfolioValue: 43210.77,
      balance: 6210.77,
      positionValue: 37000,
      pnl: 3210.77,
    },
  ];

  const displayLeaderboard: any = leaderboard || mockLeaderboard;

  const getMedalIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Medal className="w-5 h-5 text-yellow-500" />;
      case 2:
        return <Medal className="w-5 h-5 text-gray-400" />;
      case 3:
        return <Medal className="w-5 h-5 text-orange-600" />;
      default:
        return null;
    }
  };

  return (
    <MainLayout>
      <div className="container py-8">
        {/* Back Button */}
        <Link href="/">
          <a className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back to Markets
          </a>
        </Link>

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Leaderboard</h1>
          <p className="text-muted-foreground">
            Top traders ranked by portfolio value
          </p>
        </div>

        {/* Leaderboard Table */}
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Spinner className="w-8 h-8" />
          </div>
        ) : (
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-[hsl(var(--border))] bg-card/50">
                    <th className="text-left py-4 px-6 font-semibold">Rank</th>
                    <th className="text-left py-4 px-6 font-semibold">Trader</th>
                    <th className="text-right py-4 px-6 font-semibold">
                      Portfolio Value
                    </th>
                    <th className="text-right py-4 px-6 font-semibold">Balance</th>
                    <th className="text-right py-4 px-6 font-semibold">
                      Position Value
                    </th>
                    <th className="text-right py-4 px-6 font-semibold">P&L</th>
                  </tr>
                </thead>
                <tbody>
                  {displayLeaderboard.map((trader: any, idx: number) => (
                    <tr
                      key={trader.userId}
                      className={`border-b border-[hsl(var(--border))]/50 transition-colors hover:bg-card/30 ${
                        idx % 2 === 0 ? "bg-background/20" : ""
                      }`}
                    >
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-3">
                          {getMedalIcon(trader.rank)}
                          <span className="font-bold text-lg">
                            #{trader.rank}
                          </span>
                        </div>
                      </td>

                      <td className="py-4 px-6">
                        <div>
                          <p className="font-semibold">{trader.userName}</p>
                          <p className="text-xs text-muted-foreground">
                            ID: {trader.userId}
                          </p>
                        </div>
                      </td>

                      <td className="text-right py-4 px-6">
                        <p className="font-semibold text-accent">
                          $
                          {trader.portfolioValue.toLocaleString("en-US", {
                            maximumFractionDigits: 2,
                          })}
                        </p>
                      </td>

                      <td className="text-right py-4 px-6">
                        <p className="font-semibold">
                          $
                          {trader.balance.toLocaleString("en-US", {
                            maximumFractionDigits: 2,
                          })}
                        </p>
                      </td>

                      <td className="text-right py-4 px-6">
                        <p className="font-semibold">
                          $
                          {trader.positionValue.toLocaleString("en-US", {
                            maximumFractionDigits: 2,
                          })}
                        </p>
                      </td>

                      <td className="text-right py-4 px-6">
                        <div className="flex items-center justify-end gap-2">
                          <p
                            className={`font-semibold ${
                              (trader.pnl as number) >= 0
                                ? "text-green-500"
                                : "text-red-500"
                            }`}
                          >
                            $
                            {Math.abs(trader.pnl as number).toLocaleString("en-US", {
                              maximumFractionDigits: 2,
                            })}
                          </p>
                          {(trader.pnl as number) >= 0 ? (
                            <TrendingUp className="w-4 h-4 text-green-500" />
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
          <Card className="p-6">
            <p className="text-sm text-muted-foreground mb-2">Total Traders</p>
            <p className="text-2xl font-bold">
              {displayLeaderboard.length.toLocaleString()}
            </p>
          </Card>

          <Card className="p-6">
            <p className="text-sm text-muted-foreground mb-2">
              Top Portfolio Value
            </p>
            <p className="text-2xl font-bold text-accent">
              $
              {displayLeaderboard[0]?.portfolioValue.toLocaleString("en-US", {
                maximumFractionDigits: 2,
              })}
            </p>
          </Card>

          <Card className="p-6">
            <p className="text-sm text-muted-foreground mb-2">
              Average Portfolio Value
            </p>
            <p className="text-2xl font-bold">
              $
              {(
                displayLeaderboard.reduce(
                  (sum: number, t: any) => sum + (typeof t.portfolioValue === 'string' ? parseFloat(t.portfolioValue) : t.portfolioValue),
                  0
                ) / displayLeaderboard.length
              ).toLocaleString("en-US", { maximumFractionDigits: 2 })}
            </p>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
}
