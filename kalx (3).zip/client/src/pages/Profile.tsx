import { useState } from "react";
import MainLayout from "@/components/MainLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui/spinner";
import { ArrowLeft, LogOut } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

export default function Profile() {
  const { isAuthenticated, user, logout } = useAuth();
  const [isSaving, setIsSaving] = useState(false);

  if (!isAuthenticated || !user) {
    return (
      <MainLayout>
        <div className="container py-12 text-center">
          <p className="text-muted-foreground mb-4">
            Please sign in to view your profile
          </p>
          <Link href="/">
            <a className="text-accent hover:text-accent/80">Back to Markets</a>
          </Link>
        </div>
      </MainLayout>
    );
  }

  const handleLogout = async () => {
    setIsSaving(true);
    await logout();
    setIsSaving(false);
  };

  return (
    <MainLayout>
      <div className="container py-8">
        {/* Back Button */}
        <Link href="/">
          <a className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back to Markets
          </a>
        </Link>

        {/* Profile Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Profile Settings</h1>
          <p className="text-muted-foreground">Manage your KalX account</p>
        </div>

        {/* Profile Information */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Account Information */}
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4">Account Information</h2>
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-muted-foreground">Name</label>
                  <p className="text-lg font-medium">{user.name || "Not set"}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Email</label>
                  <p className="text-lg font-medium">{user.email || "Not set"}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">User ID</label>
                  <p className="text-lg font-medium font-mono text-xs">{user.id}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Account Type</label>
                  <p className="text-lg font-medium capitalize">{user.role}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Member Since</label>
                  <p className="text-lg font-medium">
                    {new Date(user.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
            </Card>

            {/* Preferences */}
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4">Preferences</h2>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Email Notifications</p>
                    <p className="text-sm text-muted-foreground">
                      Receive updates about your markets
                    </p>
                  </div>
                  <input type="checkbox" defaultChecked className="w-4 h-4" />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Market Alerts</p>
                    <p className="text-sm text-muted-foreground">
                      Get notified when markets you follow resolve
                    </p>
                  </div>
                  <input type="checkbox" defaultChecked className="w-4 h-4" />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Weekly Summary</p>
                    <p className="text-sm text-muted-foreground">
                      Receive a summary of your portfolio performance
                    </p>
                  </div>
                  <input type="checkbox" defaultChecked className="w-4 h-4" />
                </div>
              </div>
            </Card>

            {/* Danger Zone */}
            <Card className="p-6 border-red-500/20">
              <h2 className="text-xl font-semibold mb-4 text-red-500">Danger Zone</h2>
              <div className="space-y-4">
                <div>
                  <p className="font-medium mb-2">Logout</p>
                  <p className="text-sm text-muted-foreground mb-4">
                    Sign out from your KalX account on this device
                  </p>
                  <Button
                    variant="outline"
                    className="text-red-500 border-red-500/50 hover:bg-red-500/10"
                    onClick={handleLogout}
                    disabled={isSaving}
                  >
                    {isSaving ? (
                      <>
                        <Spinner className="w-4 h-4 mr-2" />
                        Logging out...
                      </>
                    ) : (
                      <>
                        <LogOut className="w-4 h-4 mr-2" />
                        Logout
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Account Stats</h3>
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-muted-foreground">Total Trades</p>
                  <p className="text-2xl font-bold">0</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Markets Followed</p>
                  <p className="text-2xl font-bold">0</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Comments Posted</p>
                  <p className="text-2xl font-bold">0</p>
                </div>
              </div>
            </Card>

            {/* Help */}
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Need Help?</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Check out our documentation or contact support
              </p>
              <Button variant="outline" className="w-full text-sm">
                View Documentation
              </Button>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
