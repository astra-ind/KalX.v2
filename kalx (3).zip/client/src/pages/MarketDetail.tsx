import { useState } from "react";
import { useParams, Link } from "wouter";
import MainLayout from "@/components/MainLayout";
import PriceChart from "@/components/PriceChart";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Spinner } from "@/components/ui/spinner";
import { ArrowLeft, TrendingUp, TrendingDown, MessageCircle, Share2 } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import ShareButton from "@/components/ShareButton";

export default function MarketDetail() {
  const { id } = useParams<{ id: string }>();
  const { isAuthenticated } = useAuth();
  const marketId = parseInt(id || "0", 10);

  const [activeTab, setActiveTab] = useState("trade");
  const [buyShares, setBuyShares] = useState("");
  const [sellShares, setSellShares] = useState("");
  const [selectedOutcome, setSelectedOutcome] = useState(0);

  // Fetch market details
  const { data: market, isLoading } = trpc.markets.getById.useQuery(
    { id: marketId },
    { enabled: marketId > 0, refetchInterval: 5000 }
  );

  // Fetch comments
  const { data: comments } = trpc.comments.list.useQuery(
    { marketId, limit: 50 },
    { enabled: marketId > 0, refetchInterval: 10000 }
  );

  // Mock market data for demonstration
  const mockMarket: any = {
    id: marketId,
    title: "Will Bitcoin reach $100k by end of 2026?",
    description:
      "This market resolves to YES if Bitcoin's price reaches $100,000 USD on any major exchange (Coinbase, Kraken, Binance) at any point before December 31, 2026 23:59:59 UTC. Otherwise, it resolves to NO.",
    category: "Crypto",
    outcomes: ["YES", "NO"],
    type: "binary",
    status: "active",
    probability: 0.55,
    volume: 2500000,
    liquidityParameter: 100,
    shares: { YES: 15000, NO: 5000 },
    expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    priceHistory: [
      { timestamp: Date.now() - 7 * 24 * 60 * 60 * 1000, price: 0.45 },
      { timestamp: Date.now() - 5 * 24 * 60 * 60 * 1000, price: 0.52 },
      { timestamp: Date.now() - 3 * 24 * 60 * 60 * 1000, price: 0.68 },
      { timestamp: Date.now(), price: 0.55 },
    ],
  };

  const displayMarket: any = market || mockMarket;

  if (isLoading && !market) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center min-h-screen">
          <Spinner className="w-8 h-8" />
        </div>
      </MainLayout>
    );
  }

  const handleBuyShares = () => {
    if (!isAuthenticated) {
      toast.error("Please sign in to trade");
      return;
    }
    if (!buyShares || parseFloat(buyShares) <= 0) {
      toast.error("Enter a valid number of shares");
      return;
    }
    toast.success(`Bought ${buyShares} shares of ${displayMarket.outcomes[selectedOutcome]}`);
    setBuyShares("");
  };

  const handleSellShares = () => {
    if (!isAuthenticated) {
      toast.error("Please sign in to trade");
      return;
    }
    if (!sellShares || parseFloat(sellShares) <= 0) {
      toast.error("Enter a valid number of shares");
      return;
    }
    toast.success(`Sold ${sellShares} shares of ${displayMarket.outcomes[selectedOutcome]}`);
    setSellShares("");
  };

  const daysUntilExpiry = Math.ceil(
    (displayMarket.expiresAt.getTime() - Date.now()) / (1000 * 60 * 60 * 24)
  );

  const probability = displayMarket.probability || 0.5;

  return (
    <MainLayout>
      <div className="container py-8">
        {/* Back Button */}
        <Link href="/">
          <button className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back to Markets
          </button>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Market Header */}
            <Card className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <p className="text-sm text-muted-foreground mb-2">
                    {displayMarket.category}
                  </p>
                  <h1 className="text-2xl sm:text-3xl font-bold mb-2">
                    {displayMarket.title}
                  </h1>
                </div>
                <div className="flex-shrink-0 text-right ml-4">
                  <div className="text-3xl font-bold text-accent">
                    {(probability * 100).toFixed(0)}%
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {displayMarket.outcomes?.[0]} probability
                  </p>
                </div>
              </div>

              <p className="text-muted-foreground mb-4">
                {displayMarket.description}
              </p>

              <div className="grid grid-cols-3 gap-4 pt-4 border-t border-slate-700">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Volume</p>
                  <p className="font-semibold">
                    ${(displayMarket.volume / 1000000).toFixed(1)}M
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Expires in</p>
                  <p className="font-semibold">{daysUntilExpiry} days</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Created</p>
                  <p className="font-semibold">
                    {displayMarket.createdAt?.toLocaleDateString?.() || new Date().toLocaleDateString()}
                  </p>
                </div>
              </div>
            </Card>

            {/* Price Chart */}
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Price History</h3>
              <PriceChart data={displayMarket.priceHistory || []} height={250} />
            </Card>

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="trade">Trade</TabsTrigger>
                <TabsTrigger value="comments">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Comments
                </TabsTrigger>
              </TabsList>

              {/* Trade Tab */}
              <TabsContent value="trade" className="space-y-4">
                <Card className="p-6">
                  <h3 className="font-semibold mb-4">Place Order</h3>

                  {/* Outcome Selection */}
                  <div className="grid grid-cols-2 gap-2 mb-6">
                    {displayMarket.outcomes?.map((outcome: string, idx: number) => (
                      <button
                        key={idx}
                        onClick={() => setSelectedOutcome(idx)}
                        className={`p-3 rounded-lg border-2 transition-all ${
                          selectedOutcome === idx
                            ? "border-accent bg-accent/10"
                            : "border-slate-700 hover:border-accent/50"
                        }`}
                      >
                        <div className="font-semibold">{outcome}</div>
                        <div className="text-sm text-muted-foreground">
                          {(
                            (idx === 0
                              ? probability
                              : 1 - probability) * 100
                          ).toFixed(0)}%
                        </div>
                      </button>
                    ))}
                  </div>

                  {/* Buy Section */}
                  <div className="mb-6 p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                    <div className="flex items-center gap-2 mb-3">
                      <TrendingUp className="w-4 h-4 text-green-500" />
                      <h4 className="font-semibold">Buy Shares</h4>
                    </div>
                    <div className="space-y-2">
                      <Input
                        type="number"
                        placeholder="Number of shares"
                        value={buyShares}
                        onChange={(e) => setBuyShares(e.target.value)}
                        className="bg-background"
                      />
                      <div className="flex justify-between text-sm text-muted-foreground">
                        <span>Price per share:</span>
                        <span>
                          ${(probability).toFixed(4)}
                        </span>
                      </div>
                      {buyShares && (
                        <div className="flex justify-between text-sm font-semibold">
                          <span>Total cost:</span>
                          <span>
                            ${(
                              parseFloat(buyShares) * probability
                            ).toFixed(2)}
                          </span>
                        </div>
                      )}
                      <Button
                        onClick={handleBuyShares}
                        className="w-full bg-green-600 hover:bg-green-700 text-white"
                      >
                        Buy Shares
                      </Button>
                    </div>
                  </div>

                  {/* Sell Section */}
                  <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                    <div className="flex items-center gap-2 mb-3">
                      <TrendingDown className="w-4 h-4 text-red-500" />
                      <h4 className="font-semibold">Sell Shares</h4>
                    </div>
                    <div className="space-y-2">
                      <Input
                        type="number"
                        placeholder="Number of shares"
                        value={sellShares}
                        onChange={(e) => setSellShares(e.target.value)}
                        className="bg-background"
                      />
                      <div className="flex justify-between text-sm text-muted-foreground">
                        <span>Price per share:</span>
                        <span>
                          ${(probability).toFixed(4)}
                        </span>
                      </div>
                      {sellShares && (
                        <div className="flex justify-between text-sm font-semibold">
                          <span>Total proceeds:</span>
                          <span>
                            ${(
                              parseFloat(sellShares) * probability
                            ).toFixed(2)}
                          </span>
                        </div>
                      )}
                      <Button
                        onClick={handleSellShares}
                        className="w-full bg-red-600 hover:bg-red-700 text-white"
                      >
                        Sell Shares
                      </Button>
                    </div>
                  </div>
                </Card>
              </TabsContent>

              {/* Comments Tab */}
              <TabsContent value="comments" className="space-y-4">
                <Card className="p-6">
                  <h3 className="font-semibold mb-4">Discussion</h3>
                  {comments && comments.length > 0 ? (
                    <div className="space-y-4">
                      {comments.map((comment: any) => (
                        <div
                          key={comment.id}
                          className="pb-4 border-b border-slate-700 last:border-b-0"
                        >
                          <div className="flex items-start justify-between mb-1">
                            <p className="font-semibold text-sm">User</p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(comment.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          <p className="text-sm text-foreground">
                            {comment.content}
                          </p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground text-sm">
                      No comments yet. Be the first to comment!
                    </p>
                  )}
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Share Button */}
            <Card className="p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Share2 className="w-4 h-4" />
                Share Market
              </h3>
              <ShareButton marketId={marketId} marketTitle={displayMarket.title} probability={probability * 100} />
            </Card>

            {/* Outcomes */}
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Outcomes</h3>
              <div className="space-y-3">
                {displayMarket.outcomes?.map((outcome: string, idx: number) => {
                  const prob =
                    idx === 0
                      ? probability
                      : 1 - probability;
                  return (
                    <div key={idx} className="flex items-center justify-between">
                      <span className="text-sm">{outcome}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-accent"
                            style={{ width: `${prob * 100}%` }}
                          />
                        </div>
                        <span className="text-sm font-semibold w-12 text-right">
                          {(prob * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>

            {/* Market Info */}
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Market Info</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Type</span>
                  <span className="font-semibold capitalize">{displayMarket.type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status</span>
                  <span className="font-semibold capitalize text-green-500">{displayMarket.status}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Liquidity</span>
                  <span className="font-semibold">${typeof displayMarket.liquidityParameter === 'number' ? displayMarket.liquidityParameter.toFixed(0) : '100'}</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
