import MainLayout from "@/components/MainLayout";
import MarketCard from "@/components/MarketCard";
import CategoryFilter from "@/components/CategoryFilter";
import { Spinner } from "@/components/ui/spinner";
import { Search, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useState, useMemo } from "react";

export default function Home() {
  const { isAuthenticated, user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [limit] = useState(50);

  // Fetch real markets from database via tRPC with real-time polling
  const { data: marketsData, isLoading, error } = trpc.markets.list.useQuery({
    limit,
    offset: 0,
    category: selectedCategory || undefined,
  }, {
    refetchInterval: 3000, // Refetch every 3 seconds for real-time updates
  });

  // Use only real data - no fallback to mock
  const markets = marketsData || [];

  // Filter markets based on search query and category
  const filteredMarkets = useMemo(() => {
    return markets.filter((market: any) => {
      const matchesSearch = market.title.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = !selectedCategory || market.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory, markets]);

  return (
    <MainLayout>
      {/* Hero Section */}
      <div className="border-b bg-gradient-to-b from-card/50 to-background py-8 sm:py-12" style={{ borderColor: "hsl(var(--border))" }}>
        <div className="container">
          <div className="max-w-2xl">
            <h1 className="text-3xl sm:text-4xl font-bold mb-2">
              Predict. Trade. Profit.
            </h1>
            <p className="text-muted-foreground mb-6">
              Trade on real-world outcomes with virtual tokens. No real money,
              pure prediction market fun.
            </p>
            {isAuthenticated && user?.role === "admin" && (
              <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">
                <Plus className="w-4 h-4 mr-2" />
                Create Market
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-8 sm:py-12">
        {/* Search and Filter Section */}
        <div className="space-y-6 mb-8">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search markets..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-card rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
              style={{ borderColor: "hsl(var(--border))", border: "1px solid hsl(var(--border))" }}
            />
          </div>

          {/* Category Filter */}
          <CategoryFilter
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
          />
        </div>

        {/* Error State */}
        {error && (
          <div className="text-center py-12 text-red-400">
            <p className="mb-2">Error loading markets</p>
            <p className="text-sm text-muted-foreground">{error.message}</p>
          </div>
        )}

        {/* Loading State */}
        {isLoading && !marketsData ? (
          <div className="flex items-center justify-center py-12">
            <Spinner className="w-8 h-8" />
          </div>
        ) : filteredMarkets.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-2">No markets found</p>
            <p className="text-sm text-muted-foreground">
              Try adjusting your search or filters
            </p>
          </div>
        ) : (
          /* Markets Grid */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMarkets.map((market: any) => (
              <MarketCard key={market.id} market={market} />
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
