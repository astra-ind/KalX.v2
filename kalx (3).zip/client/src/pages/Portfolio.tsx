import MainLayout from "@/components/MainLayout";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui/spinner";
import { TrendingUp, TrendingDown, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useState } from "react";

export default function Portfolio() {
  const { isAuthenticated, user } = useAuth();
  const [activeTab, setActiveTab] = useState("positions");

  // Fetch user positions with real-time updates
  const { data: positions, isLoading: positionsLoading } =
    trpc.portfolio.getPositions.useQuery(undefined, {
      enabled: isAuthenticated,
      refetchInterval: 5000,
    });

  // Fetch user transactions with real-time updates
  const { data: transactions, isLoading: transactionsLoading } =
    trpc.portfolio.getTransactions.useQuery(
      { limit: 100 },
      { enabled: isAuthenticated, refetchInterval: 10000 }
    );

  // Fetch user balance with real-time updates
  const { data: balance, isLoading: balanceLoading } =
    trpc.portfolio.getBalance.useQuery(undefined, {
      enabled: isAuthenticated,
      refetchInterval: 5000,
    });

  if (!isAuthenticated) {
    return (
      <MainLayout>
        <div className="container py-12 text-center">
          <p className="text-muted-foreground mb-4">
            Please sign in to view your portfolio
          </p>
          <Link href="/">
            <a className="text-accent hover:text-accent/80">Back to Markets</a>
          </Link>
        </div>
      </MainLayout>
    );
  }

  const isLoading = positionsLoading || transactionsLoading || balanceLoading;

  return (
    <MainLayout>
      <div className="container py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <Link href="/">
              <a className="text-accent hover:text-accent/80">
                <ArrowLeft className="w-5 h-5" />
              </a>
            </Link>
            <h1 className="text-3xl font-bold">Your Portfolio</h1>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Spinner className="w-8 h-8" />
          </div>
        ) : (
          <>
            {/* Portfolio Summary */}
            {balance && typeof balance === 'object' && (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                <Card className="p-4">
                  <p className="text-sm text-muted-foreground mb-1">Available Balance</p>
                  <p className="text-2xl font-bold text-accent">
                    ${(balance as any).available?.toLocaleString() || "0"}
                  </p>
                </Card>
                <Card className="p-4">
                  <p className="text-sm text-muted-foreground mb-1">Total Invested</p>
                  <p className="text-2xl font-bold">
                    ${(balance as any).invested?.toLocaleString() || "0"}
                  </p>
                </Card>
                <Card className="p-4">
                  <p className="text-sm text-muted-foreground mb-1">Portfolio Value</p>
                  <p className="text-2xl font-bold">
                    ${(balance as any).total?.toLocaleString() || "0"}
                  </p>
                </Card>
                <Card className="p-4">
                  <p className="text-sm text-muted-foreground mb-1">P&L</p>
                  <p className={`text-2xl font-bold ${((balance as any).pnl || 0) >= 0 ? "text-green-500" : "text-red-500"}`}>
                    ${(balance as any).pnl?.toLocaleString() || "0"}
                  </p>
                </Card>
              </div>
            )}

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-6">
                <TabsTrigger value="positions">Open Positions</TabsTrigger>
                <TabsTrigger value="transactions">Transaction History</TabsTrigger>
              </TabsList>

              {/* Positions Tab */}
              <TabsContent value="positions">
                {positions && positions.length > 0 ? (
                  <div className="space-y-4">
                    {positions.map((position: any) => (
                      <Card key={position.id} className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h3 className="font-semibold text-foreground">
                              {position.marketTitle}
                            </h3>
                            <p className="text-sm text-muted-foreground">
                              {position.outcome} • {position.shares} shares
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-foreground">
                              ${position.value?.toLocaleString() || "0"}
                            </p>
                            <p className={`text-sm ${(position as any).pnl >= 0 ? "text-green-500" : "text-red-500"}`}>
                              {(position as any).pnl >= 0 ? "+" : ""}{(position as any).pnl?.toLocaleString() || "0"} ({(position as any).pnlPercent || 0}%)
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>Avg Entry: ${position.avgEntryPrice?.toFixed(2) || "0.00"}</span>
                          <span>Current: ${position.currentPrice?.toFixed(2) || "0.00"}</span>
                        </div>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">No open positions</p>
                  </div>
                )}
              </TabsContent>

              {/* Transactions Tab */}
              <TabsContent value="transactions">
                {transactions && transactions.length > 0 ? (
                  <div className="space-y-2">
                    {transactions.map((tx: any) => (
                      <Card key={tx.id} className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            {tx.type === "BUY" ? (
                              <TrendingUp className="w-5 h-5 text-green-500" />
                            ) : (
                              <TrendingDown className="w-5 h-5 text-red-500" />
                            )}
                            <div>
                              <p className="font-semibold text-foreground">
                                {tx.type} {tx.shares} {tx.outcome}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {tx.market}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-foreground">
                              ${tx.total?.toLocaleString() || "0"}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(tx.timestamp).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">No transactions yet</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </MainLayout>
  );
}
