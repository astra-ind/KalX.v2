import { useEffect, useRef, useCallback } from 'react';
import io, { Socket } from 'socket.io-client';

interface WebSocketConfig {
  url?: string;
  autoConnect?: boolean;
}

export function useWebSocket(config: WebSocketConfig = {}) {
  const socketRef = useRef<Socket | null>(null);
  const { url = window.location.origin, autoConnect = true } = config;

  useEffect(() => {
    if (!autoConnect || socketRef.current?.connected) return;

    try {
      socketRef.current = io(url, {
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        reconnectionAttempts: 5,
        transports: ['websocket', 'polling'],
      });

      socketRef.current.on('connect', () => {
        console.log('[WebSocket] Connected');
      });

      socketRef.current.on('disconnect', () => {
        console.log('[WebSocket] Disconnected');
      });

      socketRef.current.on('connect_error', (error: any) => {
        console.error('[WebSocket] Connection error:', error);
      });
    } catch (error) {
      console.error('[WebSocket] Failed to initialize:', error);
    }

    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
    };
  }, [url, autoConnect]);

  const subscribe = useCallback((event: string, callback: (data: any) => void) => {
    if (!socketRef.current) return;
    socketRef.current.on(event, callback);
    return () => {
      if (socketRef.current) {
        socketRef.current.off(event, callback);
      }
    };
  }, []);

  const emit = useCallback((event: string, data?: any) => {
    if (!socketRef.current) return;
    socketRef.current.emit(event, data);
  }, []);

  const subscribeToMarket = useCallback((marketId: number) => {
    if (!socketRef.current) return;
    socketRef.current.emit('subscribe:market', marketId);
  }, []);

  const unsubscribeFromMarket = useCallback((marketId: number) => {
    if (!socketRef.current) return;
    socketRef.current.emit('unsubscribe:market', marketId);
  }, []);

  const subscribeToAll = useCallback(() => {
    if (!socketRef.current) return;
    socketRef.current.emit('subscribe:all');
  }, []);

  return {
    socket: socketRef.current,
    subscribe,
    emit,
    subscribeToMarket,
    unsubscribeFromMarket,
    subscribeToAll,
    isConnected: socketRef.current?.connected ?? false,
  };
}
