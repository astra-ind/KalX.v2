import { describe, expect, it } from "vitest";
import {
  calculateCostLMSR,
  calculateProceedsLMSR,
  calculateProbabilityLMSR,
  calculatePricePerShareLMSR,
  initializeQuantities,
  validateLMSRParams,
  calculateMarketMakerProfit,
} from "./amm";

describe("LMSR AMM", () => {
  describe("initializeQuantities", () => {
    it("creates array of correct size with default 0", () => {
      const quantities = initializeQuantities(2);
      expect(quantities).toEqual([0, 0]);
    });

    it("creates array with custom initial quantity", () => {
      const quantities = initializeQuantities(3, 10);
      expect(quantities).toEqual([10, 10, 10]);
    });
  });

  describe("validateLMSRParams", () => {
    it("validates correct parameters", () => {
      const result = validateLMSRParams([0, 0], 100);
      expect(result.valid).toBe(true);
    });

    it("rejects empty quantities", () => {
      const result = validateLMSRParams([], 100);
      expect(result.valid).toBe(false);
    });

    it("rejects non-positive liquidity parameter", () => {
      const result = validateLMSRParams([0, 0], 0);
      expect(result.valid).toBe(false);
    });

    it("rejects negative quantities", () => {
      const result = validateLMSRParams([0, -1], 100);
      expect(result.valid).toBe(false);
    });
  });

  describe("calculateCostLMSR", () => {
    it("returns 0 for 0 shares", () => {
      const cost = calculateCostLMSR([0, 0], 0, 0, 100);
      expect(cost).toBe(0);
    });

    it("calculates cost for buying YES shares", () => {
      const quantities = [0, 0];
      const cost = calculateCostLMSR(quantities, 0, 10, 100);
      expect(cost).toBeGreaterThan(0);
      expect(cost).toBeLessThan(10); // Should be less than face value
    });

    it("cost increases with more shares", () => {
      const quantities = [0, 0];
      const cost1 = calculateCostLMSR(quantities, 0, 10, 100);
      const cost2 = calculateCostLMSR(quantities, 0, 20, 100);
      expect(cost2).toBeGreaterThan(cost1);
    });

    it("cost increases with existing imbalance", () => {
      const cost1 = calculateCostLMSR([0, 0], 0, 10, 100);
      const cost2 = calculateCostLMSR([50, 0], 0, 10, 100);
      expect(cost2).toBeGreaterThan(cost1);
    });

    it("throws on invalid outcome index", () => {
      expect(() => calculateCostLMSR([0, 0], 5, 10, 100)).toThrow();
    });
  });

  describe("calculateProceedsLMSR", () => {
    it("returns 0 for 0 shares", () => {
      const proceeds = calculateProceedsLMSR([10, 10], 0, 0, 100);
      expect(proceeds).toBe(0);
    });

    it("calculates proceeds for selling shares", () => {
      const quantities = [100, 50];
      const proceeds = calculateProceedsLMSR(quantities, 0, 10, 100);
      expect(proceeds).toBeGreaterThan(0);
      expect(proceeds).toBeLessThan(10);
    });

    it("throws when selling more shares than held", () => {
      expect(() => calculateProceedsLMSR([5, 10], 0, 10, 100)).toThrow();
    });

    it("selling and buying same amount is not equal (slippage)", () => {
      const quantities = [50, 50];
      const buyCost = calculateCostLMSR(quantities, 0, 10, 100);
      const sellProceeds = calculateProceedsLMSR(quantities, 0, 10, 100);
      expect(buyCost).toBeGreaterThan(sellProceeds);
    });
  });

  describe("calculateProbabilityLMSR", () => {
    it("returns 0.5 for equal quantities", () => {
      const prob = calculateProbabilityLMSR([100, 100], 0, 100);
      expect(prob).toBeCloseTo(0.5, 5);
    });

    it("returns higher probability for higher quantity", () => {
      const prob1 = calculateProbabilityLMSR([100, 100], 0, 100);
      const prob2 = calculateProbabilityLMSR([150, 100], 0, 100);
      expect(prob2).toBeGreaterThan(prob1);
    });

    it("probabilities sum to 1", () => {
      const quantities = [75, 125];
      const prob0 = calculateProbabilityLMSR(quantities, 0, 100);
      const prob1 = calculateProbabilityLMSR(quantities, 1, 100);
      expect(prob0 + prob1).toBeCloseTo(1, 5);
    });

    it("handles multi-outcome markets", () => {
      const quantities = [100, 100, 100];
      const prob0 = calculateProbabilityLMSR(quantities, 0, 100);
      const prob1 = calculateProbabilityLMSR(quantities, 1, 100);
      const prob2 = calculateProbabilityLMSR(quantities, 2, 100);
      expect(prob0 + prob1 + prob2).toBeCloseTo(1, 5);
      expect(prob0).toBeCloseTo(1 / 3, 5);
    });
  });

  describe("calculatePricePerShareLMSR", () => {
    it("price equals probability", () => {
      const quantities = [100, 50];
      const price = calculatePricePerShareLMSR(quantities, 0, 100);
      const prob = calculateProbabilityLMSR(quantities, 0, 100);
      expect(price).toBeCloseTo(prob, 10);
    });

    it("price is between 0 and 1", () => {
      const quantities = [100, 50];
      const price = calculatePricePerShareLMSR(quantities, 0, 100);
      expect(price).toBeGreaterThan(0);
      expect(price).toBeLessThan(1);
    });
  });

  describe("calculateMarketMakerProfit", () => {
    it("returns 0 for no shares", () => {
      const profit = calculateMarketMakerProfit([0, 0], 100);
      expect(profit).toBeCloseTo(0, 5);
    });

    it("returns positive profit when shares are bought", () => {
      const quantities = [100, 50];
      const profit = calculateMarketMakerProfit(quantities, 100);
      expect(profit).toBeGreaterThan(0);
    });

    it("profit increases with more trading", () => {
      const profit1 = calculateMarketMakerProfit([50, 50], 100);
      const profit2 = calculateMarketMakerProfit([100, 100], 100);
      expect(profit2).toBeGreaterThan(profit1);
    });
  });

  describe("Integration: Buy then Sell", () => {
    it("buying and selling same amount results in loss (slippage)", () => {
      let quantities = [0, 0];
      const buyCost = calculateCostLMSR(quantities, 0, 10, 100);
      quantities[0] += 10;

      const sellProceeds = calculateProceedsLMSR(quantities, 0, 10, 100);

      // Due to LMSR mechanics, selling after buying should yield less than cost
      // (accounting for the market maker's spread)
      expect(sellProceeds).toBeLessThanOrEqual(buyCost);
    });

    it("multiple trades converge to equilibrium", () => {
      let quantities = [0, 0];
      
      // Buy 100 YES shares
      quantities[0] += 100;
      let prob = calculateProbabilityLMSR(quantities, 0, 100);
      expect(prob).toBeGreaterThan(0.5);

      // Buy 100 NO shares
      quantities[1] += 100;
      prob = calculateProbabilityLMSR(quantities, 0, 100);
      expect(prob).toBeCloseTo(0.5, 1);
    });
  });

  describe("Liquidity parameter effects", () => {
    it("higher liquidity means lower price impact per share", () => {
      const quantities = [0, 0];
      const cost1 = calculateCostLMSR(quantities, 0, 10, 50);
      const cost2 = calculateCostLMSR(quantities, 0, 10, 200);
      // Higher liquidity parameter = lower price per share on average
      const pricePerShare1 = cost1 / 10;
      const pricePerShare2 = cost2 / 10;
      expect(pricePerShare2).toBeLessThan(pricePerShare1);
    });

    it("lower liquidity means higher price impact per share", () => {
      const quantities = [50, 50];
      const cost1 = calculateCostLMSR(quantities, 0, 10, 50);
      const cost2 = calculateCostLMSR(quantities, 0, 10, 200);
      const pricePerShare1 = cost1 / 10;
      const pricePerShare2 = cost2 / 10;
      expect(pricePerShare1).toBeGreaterThan(pricePerShare2);
    });
  });
});
