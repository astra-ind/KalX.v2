import { runAutoPilotJob } from "./autoPilot";
import { getDb } from "./db";

/**
 * Heartbeat scheduler for periodic AutoPilot jobs
 * This runs on a schedule defined by the Heartbeat system
 */

export async function scheduleAutoPilotJobs() {
  console.log("[Heartbeat] Starting AutoPilot job scheduler");

  try {
    // Run market generation every 24 hours
    // This fetches trending topics and creates new markets
    console.log("[Heartbeat] Running market generation job...");
    const generationResult = await runAutoPilotJob("market_generation");
    console.log("[Heartbeat] Market generation completed:", generationResult);

    // Run market resolution every 12 hours
    // This evaluates and resolves expired markets
    console.log("[Heartbeat] Running market resolution job...");
    const resolutionResult = await runAutoPilotJob("market_resolution");
    console.log("[Heartbeat] Market resolution completed:", resolutionResult);

    // Update leaderboard snapshots
    console.log("[Heartbeat] Updating leaderboard snapshots...");
    await updateLeaderboardSnapshots();
    console.log("[Heartbeat] Leaderboard snapshots updated");

    console.log("[Heartbeat] All AutoPilot jobs completed successfully");
    return {
      success: true,
      generationResult,
      resolutionResult,
    };
  } catch (error) {
    console.error("[Heartbeat] AutoPilot job scheduler failed:", error);
    throw error;
  }
}

/**
 * Update leaderboard snapshots for historical tracking
 */
async function updateLeaderboardSnapshots() {
  const db = await getDb();
  if (!db) {
    console.warn("[Heartbeat] Cannot update leaderboard: database not available");
    return;
  }

  try {
    // Leaderboard snapshots are calculated on-demand from positions
    // This is a placeholder for future historical tracking
    console.log("[Heartbeat] Leaderboard snapshots calculation triggered");
  } catch (error) {
    console.error("[Heartbeat] Failed to update leaderboard snapshots:", error);
    throw error;
  }
}

/**
 * Export for Heartbeat integration
 * This function is called by the Heartbeat system on a schedule
 */
export default scheduleAutoPilotJobs;
