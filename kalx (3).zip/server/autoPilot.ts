/**
 * AI AutoPilot Agent
 * 
 * Periodically generates new markets from trending topics and resolves expired markets
 * using the Gemini LLM API and trending news data.
 */

import { invokeLLM } from "./_core/llm";
import * as db from "./db";
import { getDb } from "./db";
import { getTrendingTopics, generateMarketTitle, generateMarketDescription } from "./newsService";

interface MarketGenerationResult {
  title: string;
  description: string;
  category: string;
  outcomes: string[];
  expiresAt: Date;
}

interface MarketResolutionResult {
  marketId: number;
  resolved: boolean;
  outcomeIndex?: number;
  reason?: string;
}

/**
 * Generate new markets from trending topics
 */
export async function generateMarketsFromTrending(): Promise<MarketGenerationResult[]> {
  try {
    // Fetch real trending topics from NewsAPI
    const trendingTopics = await getTrendingTopics();

    // Use LLM to generate market ideas
    const prompt = `You are a prediction market expert. Given these trending topics, generate 3-5 interesting binary prediction markets that users would want to trade on.

Trending topics:
${trendingTopics.map(t => `- ${t.title} (${t.source})`).join('\n')}

For each market, provide:
1. A clear, specific title (max 100 chars)
2. A detailed description
3. Category (Politics, Finance, Sports, Crypto, Technology, Entertainment, Other)
4. Two outcomes (YES/NO format)
5. Expiration date (ISO format, 1-30 days from now)

Format your response as a JSON array with objects containing: title, description, category, outcomes (array of 2 strings), expiresAt (ISO string).`;

    const response = await invokeLLM({
      model: "gpt-5-mini",
      messages: [{ role: "user", content: prompt }],
    });

    if (!response.choices || response.choices.length === 0) {
      console.error("[AutoPilot] No choices from LLM response");
      return [];
    }

    // Parse the response
    const choice = response.choices[0];
    if (!choice || !choice.message) {
      console.error("[AutoPilot] Invalid choice structure");
      return [];
    }

    let content = choice.message.content;
    if (Array.isArray(content)) {
      const textContent = content.find(c => typeof c === 'string' || (typeof c === 'object' && 'type' in c && c.type === 'text'));
      content = typeof textContent === 'string' ? textContent : (textContent && 'text' in textContent ? textContent.text : '');
    }

    if (typeof content !== 'string') {
      console.error("[AutoPilot] Could not extract text from response");
      return [];
    }

    // Extract JSON from response (handle markdown code blocks)
    let jsonStr = content;
    const jsonMatch = jsonStr.match(/\[[\s\S]*\]/);
    if (jsonMatch) {
      jsonStr = jsonMatch[0];
    }

    const markets: MarketGenerationResult[] = JSON.parse(jsonStr);

    // Validate and create markets
    const createdMarkets = [];
    for (const market of markets) {
      try {
        // Validate market data
        if (!market.title || !market.description || !market.category || !market.outcomes || market.outcomes.length !== 2) {
          console.warn("[AutoPilot] Invalid market data:", market);
          continue;
        }

        // Create market in database (createdBy = -1 for AI-generated)
        const result = await db.createMarket({
          title: market.title,
          description: market.description,
          category: market.category,
          type: "binary",
          outcomes: market.outcomes,
          liquidityParameter: 100, // Default liquidity parameter
          expiresAt: new Date(market.expiresAt),
          createdBy: -1, // Special ID for AI-generated markets
        });

        createdMarkets.push(market);
      } catch (error) {
        console.error("[AutoPilot] Failed to create market:", error);
      }
    }

    return createdMarkets;
  } catch (error) {
    console.error("[AutoPilot] Error generating markets:", error);
    return [];
  }
}

/**
 * Resolve expired markets
 */
export async function resolveExpiredMarkets(): Promise<MarketResolutionResult[]> {
  try {
    // Get all expired markets that are still active
    const expiredMarkets = await db.getExpiredMarkets();

    if (expiredMarkets.length === 0) {
      console.log("[AutoPilot] No expired markets to resolve");
      return [];
    }

    const resolutions: MarketResolutionResult[] = [];

    for (const market of expiredMarkets) {
      try {
        // Use LLM to evaluate market outcome
        const resolution = await evaluateMarketOutcome(market);

        if (resolution.resolved && resolution.outcomeIndex !== undefined) {
          // Update market status
          await db.updateMarketStatus(market.id, "resolved", resolution.outcomeIndex);

          resolutions.push({
            marketId: market.id,
            resolved: true,
            outcomeIndex: resolution.outcomeIndex,
            reason: resolution.reason,
          });
        } else {
          resolutions.push({
            marketId: market.id,
            resolved: false,
            reason: "Could not determine outcome",
          });
        }
      } catch (error) {
        console.error(`[AutoPilot] Error resolving market ${market.id}:`, error);
        resolutions.push({
          marketId: market.id,
          resolved: false,
          reason: String(error),
        });
      }
    }

    return resolutions;
  } catch (error) {
    console.error("[AutoPilot] Error resolving markets:", error);
    return [];
  }
}

/**
 * Evaluate a market outcome using LLM
 */
async function evaluateMarketOutcome(market: any): Promise<{ resolved: boolean; outcomeIndex?: number; reason?: string }> {
  try {
    const prompt = `You are a prediction market resolver. Based on the market details below, determine which outcome occurred.

Market Title: ${market.title}
Description: ${market.description}
Outcomes: ${market.outcomes.join(" / ")}
Expired At: ${market.expiresAt}

Based on real-world events and current information, which outcome occurred? 
Respond with ONLY a JSON object: {"outcomeIndex": 0 or 1, "reason": "brief explanation"}

If you cannot determine the outcome, respond with: {"outcomeIndex": null, "reason": "reason why"}`;

    const response = await invokeLLM({
      model: "gpt-5-mini",
      messages: [{ role: "user", content: prompt }],
    });

    if (!response.choices || response.choices.length === 0) {
      return { resolved: false, reason: "No LLM response" };
    }

    const choice = response.choices[0];
    if (!choice || !choice.message) {
      return { resolved: false, reason: "Invalid choice structure" };
    }

    let content = choice.message.content;
    if (Array.isArray(content)) {
      const textContent = content.find(c => typeof c === 'string' || (typeof c === 'object' && 'type' in c && c.type === 'text'));
      content = typeof textContent === 'string' ? textContent : (textContent && 'text' in textContent ? textContent.text : '');
    }

    if (typeof content !== 'string') {
      return { resolved: false, reason: "Could not extract text from response" };
    }

    // Extract JSON from response
    let jsonStr = content;
    const jsonMatch = jsonStr.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      jsonStr = jsonMatch[0];
    }

    const result = JSON.parse(jsonStr);

    if (result.outcomeIndex === null || result.outcomeIndex === undefined) {
      return { resolved: false, reason: result.reason };
    }

    return {
      resolved: true,
      outcomeIndex: result.outcomeIndex,
      reason: result.reason,
    };
  } catch (error) {
    console.error("[AutoPilot] Error evaluating market outcome:", error);
    return { resolved: false, reason: String(error) };
  }
}



/**
 * Main AutoPilot job runner
 */
export async function runAutoPilotJob(jobType: "market_generation" | "market_resolution") {
  const jobResult = await db.createAutoPilotJob(jobType);
  const jobId = (jobResult[0]?.insertId || 0) as number;

  try {
    if (jobId > 0) {
      await db.updateAutoPilotJob(jobId, "running");
    }

    let result: any;

    if (jobType === "market_generation") {
      const markets = await generateMarketsFromTrending();
      result = {
        type: "market_generation",
        marketsCreated: markets.length,
        markets: markets,
      };
    } else if (jobType === "market_resolution") {
      const resolutions = await resolveExpiredMarkets();
      result = {
        type: "market_resolution",
        marketsResolved: resolutions.filter(r => r.resolved).length,
        resolutions: resolutions,
      };
    }

    if (jobId > 0) {
      await db.updateAutoPilotJob(jobId, "completed", result);
    }
    console.log(`[AutoPilot] Job ${jobId} completed:`, result);

    return result;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    if (jobId > 0) {
      await db.updateAutoPilotJob(jobId, "failed", undefined, errorMessage);
    }
    console.error(`[AutoPilot] Job ${jobId} failed:`, error);
    throw error;
  }
}
