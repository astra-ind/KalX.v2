import { describe, it, expect } from "vitest";
import { getTrendingTopics, generateMarketTitle, generateMarketDescription } from "./newsService";

describe("NewsService", () => {
  it("should fetch trending topics", async () => {
    const topics = await getTrendingTopics();
    expect(Array.isArray(topics)).toBe(true);
    expect(topics.length).toBeGreaterThan(0);
  });

  it("should have valid topic structure", async () => {
    const topics = await getTrendingTopics();
    const topic = topics[0];

    expect(topic).toHaveProperty("title");
    expect(topic).toHaveProperty("description");
    expect(topic).toHaveProperty("category");
    expect(topic).toHaveProperty("source");

    expect(typeof topic.title).toBe("string");
    expect(typeof topic.description).toBe("string");
    expect(typeof topic.category).toBe("string");
    expect(typeof topic.source).toBe("string");

    expect(topic.title.length).toBeGreaterThan(0);
    expect(topic.category.length).toBeGreaterThan(0);
  });

  it("should generate valid market titles", async () => {
    const topics = await getTrendingTopics();
    const topic = topics[0];
    const title = generateMarketTitle(topic);

    expect(typeof title).toBe("string");
    expect(title.length).toBeGreaterThan(0);
    expect(title.length).toBeLessThan(500);
  });

  it("should generate valid market descriptions", async () => {
    const topics = await getTrendingTopics();
    const topic = topics[0];
    const description = generateMarketDescription(topic);

    expect(typeof description).toBe("string");
    expect(description.length).toBeGreaterThan(0);
    expect(description.includes(topic.source)).toBe(true);
  });

  it("should map news categories correctly", async () => {
    const topics = await getTrendingTopics();
    const validCategories = [
      "Finance",
      "Technology",
      "Politics",
      "Sports",
      "Entertainment",
      "Other",
    ];

    for (const topic of topics) {
      expect(validCategories).toContain(topic.category);
    }
  });
});
