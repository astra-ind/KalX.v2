import { eq, and, desc, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users,
  markets,
  positions,
  transactions,
  priceHistory,
  comments,
  leaderboardSnapshots,
  autoPilotJobs,
  type Market,
  type Position,
  type Transaction,
  type Comment,
  type PriceHistory,
  type LeaderboardSnapshot,
  type AutoPilotJob,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============ MARKET QUERIES ============

export async function createMarket(market: {
  title: string;
  description?: string;
  category: string;
  type: "binary" | "multi";
  outcomes: string[];
  liquidityParameter: number;
  expiresAt: Date;
  createdBy: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(markets).values({
    title: market.title,
    description: market.description,
    category: market.category,
    type: market.type,
    outcomes: market.outcomes,
    liquidityParameter: market.liquidityParameter.toString(),
    shares: {},
    expiresAt: market.expiresAt,
    createdBy: market.createdBy,
  });

  return result;
}

export async function getMarketById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(markets).where(eq(markets.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getActiveMarkets(limit: number = 50, offset: number = 0) {
  const db = await getDb();
  if (!db) return [];

  try {
    return await db
      .select()
      .from(markets)
      .where(eq(markets.status, "active"))
      .orderBy(desc(markets.createdAt))
      .limit(limit)
      .offset(offset);
  } catch (error) {
    console.warn("[Database] Failed to fetch markets, returning mock data:", error);
    // Return mock data for demo purposes
    return [
      {
        id: 1,
        title: "Will Bitcoin reach $100k by end of 2026?",
        description: "Prediction on Bitcoin price",
        category: "Crypto",
        type: "binary",
        outcomes: ["YES", "NO"],
        liquidityParameter: "100",
        shares: {},
        status: "active",
        resolvedOutcomeIndex: null,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        volume: "2500000",
        createdBy: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 2,
        title: "Will the Fed cut rates in Q3 2026?",
        description: "Federal Reserve rate cut prediction",
        category: "Finance",
        type: "binary",
        outcomes: ["YES", "NO"],
        liquidityParameter: "100",
        shares: {},
        status: "active",
        resolvedOutcomeIndex: null,
        expiresAt: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000),
        volume: "1800000",
        createdBy: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 3,
        title: "Will Trump win the 2026 midterms?",
        description: "US midterm election prediction",
        category: "Politics",
        type: "binary",
        outcomes: ["YES", "NO"],
        liquidityParameter: "100",
        shares: {},
        status: "active",
        resolvedOutcomeIndex: null,
        expiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
        volume: "3200000",
        createdBy: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];
  }
}

export async function getMarketsByCategory(category: string, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(markets)
    .where(and(eq(markets.category, category), eq(markets.status, "active")))
    .orderBy(desc(markets.createdAt))
    .limit(limit);
}

export async function getExpiredMarkets() {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(markets)
    .where(and(eq(markets.status, "active"), lte(markets.expiresAt, new Date())));
}

export async function updateMarketStatus(
  marketId: number,
  status: "active" | "resolved" | "cancelled",
  resolvedOutcomeIndex?: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData: any = { status };
  if (resolvedOutcomeIndex !== undefined) {
    updateData.resolvedOutcomeIndex = resolvedOutcomeIndex;
  }

  return await db.update(markets).set(updateData).where(eq(markets.id, marketId));
}

// ============ POSITION QUERIES ============

export async function getUserPosition(userId: number, marketId: number, outcomeIndex: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(positions)
    .where(and(eq(positions.userId, userId), eq(positions.marketId, marketId), eq(positions.outcomeIndex, outcomeIndex)))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserPositions(userId: number, marketId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(positions)
    .where(and(eq(positions.userId, userId), eq(positions.marketId, marketId)));
}

export async function getUserAllPositions(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(positions)
    .where(eq(positions.userId, userId));
}

export async function createOrUpdatePosition(
  userId: number,
  marketId: number,
  outcomeIndex: number,
  shares: number,
  avgEntryPrice: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await getUserPosition(userId, marketId, outcomeIndex);

  if (existing) {
    // Update existing position
    return await db
      .update(positions)
      .set({
        shares: shares.toString(),
        avgEntryPrice: avgEntryPrice.toString(),
        updatedAt: new Date(),
      })
      .where(eq(positions.id, existing.id));
  } else {
    // Create new position
    return await db.insert(positions).values({
      userId,
      marketId,
      outcomeIndex,
      shares: shares.toString(),
      avgEntryPrice: avgEntryPrice.toString(),
    });
  }
}

// ============ TRANSACTION QUERIES ============

export async function createTransaction(transaction: {
  userId: number;
  marketId: number;
  type: "BUY" | "SELL";
  outcomeIndex: number;
  shares: number;
  pricePerShare: number;
  total: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(transactions).values({
    userId: transaction.userId,
    marketId: transaction.marketId,
    type: transaction.type,
    outcomeIndex: transaction.outcomeIndex,
    shares: transaction.shares.toString(),
    pricePerShare: transaction.pricePerShare.toString(),
    total: transaction.total.toString(),
  });
}

export async function getUserTransactions(userId: number, limit: number = 100) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, userId))
    .orderBy(desc(transactions.createdAt))
    .limit(limit);
}

export async function getMarketTransactions(marketId: number, limit: number = 100) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(transactions)
    .where(eq(transactions.marketId, marketId))
    .orderBy(desc(transactions.createdAt))
    .limit(limit);
}

// ============ PRICE HISTORY QUERIES ============

export async function createPriceHistory(
  marketId: number,
  outcomeIndex: number,
  price: number,
  probability: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(priceHistory).values({
    marketId,
    outcomeIndex,
    price: price.toString(),
    probability: probability.toString(),
  });
}

export async function getMarketPriceHistory(marketId: number, outcomeIndex: number, limit: number = 1000) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(priceHistory)
    .where(and(eq(priceHistory.marketId, marketId), eq(priceHistory.outcomeIndex, outcomeIndex)))
    .orderBy(desc(priceHistory.timestamp))
    .limit(limit);
}

// ============ COMMENT QUERIES ============

export async function createComment(marketId: number, userId: number, content: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(comments).values({
    marketId,
    userId,
    content,
  });
}

export async function getMarketComments(marketId: number, limit: number = 100) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(comments)
    .where(eq(comments.marketId, marketId))
    .orderBy(desc(comments.createdAt))
    .limit(limit);
}

// ============ LEADERBOARD QUERIES ============

export async function createLeaderboardSnapshot(
  userId: number,
  rank: number,
  portfolioValue: number,
  balance: number,
  positionValue: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(leaderboardSnapshots).values({
    userId,
    rank,
    portfolioValue: portfolioValue.toString(),
    balance: balance.toString(),
    positionValue: positionValue.toString(),
  });
}

export async function getLatestLeaderboard(limit: number = 100) {
  const db = await getDb();
  if (!db) return [];

  // Get the most recent snapshot for each user
  const subquery = db
    .select()
    .from(leaderboardSnapshots)
    .orderBy(desc(leaderboardSnapshots.snapshotAt))
    .limit(1);

  return await db
    .select()
    .from(leaderboardSnapshots)
    .where(eq(leaderboardSnapshots.snapshotAt, subquery))
    .orderBy(leaderboardSnapshots.rank)
    .limit(limit);
}

// ============ AUTOPILOT JOB QUERIES ============

export async function createAutoPilotJob(jobType: "market_generation" | "market_resolution") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(autoPilotJobs).values({
    jobType,
    status: "pending",
  });
}

export async function updateAutoPilotJob(
  jobId: number,
  status: "pending" | "running" | "completed" | "failed",
  result?: Record<string, unknown>,
  error?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData: any = {
    status,
    executedAt: new Date(),
  };

  if (result !== undefined) updateData.result = result;
  if (error !== undefined) updateData.error = error;

  return await db.update(autoPilotJobs).set(updateData).where(eq(autoPilotJobs.id, jobId));
}

export async function getRecentAutoPilotJobs(limit: number = 50) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(autoPilotJobs)
    .orderBy(desc(autoPilotJobs.createdAt))
    .limit(limit);
}
