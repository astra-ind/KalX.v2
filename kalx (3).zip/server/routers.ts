import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import * as db from "./db";
import * as amm from "./amm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ MARKET PROCEDURES ============
  markets: router({
    list: publicProcedure
      .input(z.object({
        limit: z.number().default(50),
        offset: z.number().default(0),
        category: z.string().optional(),
      }))
      .query(async ({ input }) => {
        if (input.category) {
          return await db.getMarketsByCategory(input.category, input.limit);
        }
        return await db.getActiveMarkets(input.limit, input.offset);
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const market = await db.getMarketById(input.id);
        if (!market) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Market not found" });
        }
        return market;
      }),

    create: protectedProcedure
      .input(z.object({
        title: z.string(),
        description: z.string().optional(),
        category: z.string(),
        type: z.enum(["binary", "multi"]),
        outcomes: z.array(z.string()).min(2),
        liquidityParameter: z.number().positive(),
        expiresAt: z.date(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Only admins can create markets manually
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can create markets" });
        }

        return await db.createMarket({
          ...input,
          createdBy: ctx.user.id,
        });
      }),

    resolve: protectedProcedure
      .input(z.object({
        marketId: z.number(),
        outcomeIndex: z.number(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can resolve markets" });
        }

        const market = await db.getMarketById(input.marketId);
        if (!market) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Market not found" });
        }

        if (input.outcomeIndex < 0 || input.outcomeIndex >= market.outcomes.length) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Invalid outcome index" });
        }

        return await db.updateMarketStatus(input.marketId, "resolved", input.outcomeIndex);
      }),
  }),

  // ============ TRADING PROCEDURES ============
  trading: router({
    buyShares: protectedProcedure
      .input(z.object({
        marketId: z.number(),
        outcomeIndex: z.number(),
        shares: z.number().positive(),
      }))
      .mutation(async ({ input, ctx }) => {
        const market = await db.getMarketById(input.marketId);
        if (!market) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Market not found" });
        }

        if (market.status !== "active") {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Market is not active" });
        }

        if (input.outcomeIndex < 0 || input.outcomeIndex >= market.outcomes.length) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Invalid outcome index" });
        }

        // Get current quantities from market shares
        const shares = market.shares as Record<number, number>;
        const quantities = market.outcomes.map((_, i) => shares[i] || 0);

        // Calculate cost using LMSR
        const cost = amm.calculateCostLMSR(
          quantities,
          input.outcomeIndex,
          input.shares,
          parseFloat(market.liquidityParameter.toString())
        );

        // Get user and check balance
        const user = await db.getUserById(ctx.user!.id);
        if (!user) {
          throw new TRPCError({ code: "NOT_FOUND", message: "User not found" });
        }

        const userBalance = parseFloat(user.balance.toString());
        if (userBalance < cost) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient balance" });
        }

        // Calculate price per share
        const pricePerShare = cost / input.shares;

        // Create transaction
        await db.createTransaction({
          userId: ctx.user!.id,
          marketId: input.marketId,
          type: "BUY",
          outcomeIndex: input.outcomeIndex,
          shares: input.shares,
          pricePerShare,
          total: cost,
        });

        // Update user balance
        const newBalance = userBalance - cost;
        // TODO: Update user balance in database

        // Update position
        const position = await db.getUserPosition(ctx.user!.id, input.marketId, input.outcomeIndex);
        const newShares = (position ? parseFloat(position.shares.toString()) : 0) + input.shares;
        const newAvgPrice = position
          ? (parseFloat(position.avgEntryPrice.toString()) * parseFloat(position.shares.toString()) + pricePerShare * input.shares) / newShares
          : pricePerShare;

        await db.createOrUpdatePosition(
          ctx.user!.id,
          input.marketId,
          input.outcomeIndex,
          newShares,
          newAvgPrice
        );

        // Update market shares
        quantities[input.outcomeIndex] += input.shares;
        const sharesRecord: Record<number, number> = {};
        quantities.forEach((q, i) => {
          sharesRecord[i] = q;
        });
        // TODO: Update market shares in database

        // Record price history
        const probability = amm.calculateProbabilityLMSR(
          quantities,
          input.outcomeIndex,
          parseFloat(market.liquidityParameter.toString())
        );
        await db.createPriceHistory(input.marketId, input.outcomeIndex, pricePerShare, probability);

        return {
          success: true,
          cost,
          pricePerShare,
          newBalance,
        };
      }),

    sellShares: protectedProcedure
      .input(z.object({
        marketId: z.number(),
        outcomeIndex: z.number(),
        shares: z.number().positive(),
      }))
      .mutation(async ({ input, ctx }) => {
        const market = await db.getMarketById(input.marketId);
        if (!market) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Market not found" });
        }

        if (market.status !== "active") {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Market is not active" });
        }

        // Get user position
        const position = await db.getUserPosition(ctx.user!.id, input.marketId, input.outcomeIndex);
        if (!position || parseFloat(position.shares.toString()) < input.shares) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient shares to sell" });
        }

        // Get current quantities from market shares
        const shares = market.shares as Record<number, number>;
        const quantities = market.outcomes.map((_, i) => shares[i] || 0);

        // Calculate proceeds using LMSR
        const proceeds = amm.calculateProceedsLMSR(
          quantities,
          input.outcomeIndex,
          input.shares,
          parseFloat(market.liquidityParameter.toString())
        );

        // Calculate price per share
        const pricePerShare = proceeds / input.shares;

        // Create transaction
        await db.createTransaction({
          userId: ctx.user!.id,
          marketId: input.marketId,
          type: "SELL",
          outcomeIndex: input.outcomeIndex,
          shares: input.shares,
          pricePerShare,
          total: proceeds,
        });

        // Update user balance
        const user = await db.getUserById(ctx.user!.id);
        if (!user) {
          throw new TRPCError({ code: "NOT_FOUND", message: "User not found" });
        }
        const userBalance = parseFloat(user.balance.toString());
        const newBalance = userBalance + proceeds;
        // TODO: Update user balance in database

        // Update position
        const newShares = parseFloat(position.shares.toString()) - input.shares;
        if (newShares > 0) {
          await db.createOrUpdatePosition(
            ctx.user!.id,
            input.marketId,
            input.outcomeIndex,
            newShares,
            parseFloat(position.avgEntryPrice.toString())
          );
        } else {
          // TODO: Delete position if shares = 0
        }

        // Update market shares
        quantities[input.outcomeIndex] -= input.shares;
        const sharesRecord: Record<number, number> = {};
        quantities.forEach((q, i) => {
          sharesRecord[i] = q;
        });
        // TODO: Update market shares in database

        // Record price history
        const probability = amm.calculateProbabilityLMSR(
          quantities,
          input.outcomeIndex,
          parseFloat(market.liquidityParameter.toString())
        );
        await db.createPriceHistory(input.marketId, input.outcomeIndex, pricePerShare, probability);

        return {
          success: true,
          proceeds,
          pricePerShare,
          newBalance,
        };
      }),
  }),

  // ============ PORTFOLIO PROCEDURES ============
  portfolio: router({
    getPositions: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserAllPositions(ctx.user!.id);
    }),

    getTransactions: protectedProcedure
      .input(z.object({ limit: z.number().default(100) }))
      .query(async ({ input, ctx }) => {
        return await db.getUserTransactions(ctx.user!.id, input.limit);
      }),

    getBalance: protectedProcedure.query(async ({ ctx }) => {
      const user = await db.getUserById(ctx.user!.id);
      return user ? parseFloat(user.balance.toString()) : 0;
    }),
  }),

  // ============ LEADERBOARD PROCEDURES ============
  leaderboard: router({
    getTop: publicProcedure
      .input(z.object({ limit: z.number().default(100) }))
      .query(async ({ input }) => {
        return await db.getLatestLeaderboard(input.limit);
      }),
  }),

  // ============ COMMENT PROCEDURES ============
  comments: router({
    list: publicProcedure
      .input(z.object({ marketId: z.number(), limit: z.number().default(100) }))
      .query(async ({ input }) => {
        return await db.getMarketComments(input.marketId, input.limit);
      }),

    create: protectedProcedure
      .input(z.object({ marketId: z.number(), content: z.string().min(1).max(1000) }))
      .mutation(async ({ input, ctx }) => {
        return await db.createComment(input.marketId, ctx.user!.id, input.content);
      }),
  }),
});

export type AppRouter = typeof appRouter;
