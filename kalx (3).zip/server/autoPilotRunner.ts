/**
 * AutoPilot Job Runner
 * 
 * Continuously manages prediction markets:
 * - Generates new markets from trending topics
 * - Updates market prices based on trading activity
 * - Resolves expired markets
 * - Manages market lifecycle
 */

import { generateMarketsFromTrending, resolveExpiredMarkets } from "./autoPilot";
import { getDb } from "./db";
import { invokeLLM } from "./_core/llm";

interface AutoPilotJobResult {
  jobType: string;
  success: boolean;
  marketsCreated?: number;
  marketsResolved?: number;
  marketsUpdated?: number;
  timestamp: Date;
  details?: string;
}

/**
 * Run a specific AutoPilot job
 */
export async function runAutoPilotJob(jobType: string): Promise<AutoPilotJobResult> {
  const startTime = Date.now();
  console.log(`[AutoPilot] Starting ${jobType} job at ${new Date().toISOString()}`);

  try {
    let result: AutoPilotJobResult;

    switch (jobType) {
      case "market_generation":
        result = await runMarketGeneration();
        break;

      case "market_resolution":
        result = await runMarketResolution();
        break;

      case "market_update":
        result = await runMarketUpdate();
        break;

      case "market_management":
        result = await runMarketManagement();
        break;

      default:
        throw new Error(`Unknown job type: ${jobType}`);
    }

    const duration = Date.now() - startTime;
    console.log(`[AutoPilot] ${jobType} completed in ${duration}ms:`, result);

    return result;
  } catch (error) {
    console.error(`[AutoPilot] Error running ${jobType}:`, error);
    return {
      jobType,
      success: false,
      timestamp: new Date(),
      details: String(error),
    };
  }
}

/**
 * Generate new markets from trending topics
 */
async function runMarketGeneration(): Promise<AutoPilotJobResult> {
  try {
    const generatedMarkets = await generateMarketsFromTrending();

    return {
      jobType: "market_generation",
      success: true,
      marketsCreated: generatedMarkets.length,
      timestamp: new Date(),
      details: `Created ${generatedMarkets.length} new markets from trending topics`,
    };
  } catch (error) {
    throw error;
  }
}

/**
 * Resolve expired markets
 */
async function runMarketResolution(): Promise<AutoPilotJobResult> {
  try {
    const resolutions = await resolveExpiredMarkets();

    const resolvedCount = resolutions.filter(r => r.resolved).length;

    return {
      jobType: "market_resolution",
      success: true,
      marketsResolved: resolvedCount,
      timestamp: new Date(),
      details: `Resolved ${resolvedCount} out of ${resolutions.length} expired markets`,
    };
  } catch (error) {
    throw error;
  }
}

/**
 * Update market prices and liquidity
 */
async function runMarketUpdate(): Promise<AutoPilotJobResult> {
  try {
    const db = await getDb();
    if (!db) {
      return {
        jobType: "market_update",
        success: false,
        timestamp: new Date(),
        details: "Database not available",
      };
    }

    // Get all active markets
    const markets = await db.select().from(require("../drizzle/schema").markets)
      .where(require("drizzle-orm").eq(require("../drizzle/schema").markets.status, "active"))
      .limit(100);

    let updatedCount = 0;

    // Update each market's price history
    for (const market of markets) {
      try {
        // Calculate current probability from shares
        const shares = market.shares || { YES: 1000, NO: 1000 };
        const totalShares = Object.values(shares).reduce((a: number, b: any) => a + (b || 0), 0);
        const probability = totalShares > 0 ? (shares.YES || 0) / totalShares : 0.5;

        // Record price history
        await db.insert(require("../drizzle/schema").priceHistory).values({
          marketId: market.id,
          price: probability,
          timestamp: new Date(),
        });

        updatedCount++;
      } catch (error) {
        console.warn(`[AutoPilot] Failed to update market ${market.id}:`, error);
      }
    }

    return {
      jobType: "market_update",
      success: true,
      marketsUpdated: updatedCount,
      timestamp: new Date(),
      details: `Updated price history for ${updatedCount} markets`,
    };
  } catch (error) {
    throw error;
  }
}

/**
 * Comprehensive market management
 */
async function runMarketManagement(): Promise<AutoPilotJobResult> {
  try {
    // Run all management tasks
    const generationResult = await runMarketGeneration();
    const resolutionResult = await runMarketResolution();
    const updateResult = await runMarketUpdate();

    const totalCreated = generationResult.marketsCreated || 0;
    const totalResolved = resolutionResult.marketsResolved || 0;
    const totalUpdated = updateResult.marketsUpdated || 0;

    return {
      jobType: "market_management",
      success: true,
      marketsCreated: totalCreated,
      marketsResolved: totalResolved,
      marketsUpdated: totalUpdated,
      timestamp: new Date(),
      details: `Created ${totalCreated}, Resolved ${totalResolved}, Updated ${totalUpdated} markets`,
    };
  } catch (error) {
    throw error;
  }
}

/**
 * Get AutoPilot job status
 */
export async function getAutoPilotStatus(): Promise<{
  isRunning: boolean;
  lastRun?: Date;
  nextRun?: Date;
  jobQueue: string[];
}> {
  return {
    isRunning: false, // Placeholder - would track actual state
    jobQueue: ["market_generation", "market_resolution", "market_update"],
  };
}

/**
 * Schedule continuous AutoPilot execution
 */
export function scheduleAutoPilotContinuous(intervalMs: number = 3600000) {
  console.log(`[AutoPilot] Scheduling continuous execution every ${intervalMs}ms`);

  // Run immediately on startup
  runAutoPilotJob("market_management").catch(err =>
    console.error("[AutoPilot] Initial run failed:", err)
  );

  // Schedule periodic runs
  setInterval(() => {
    runAutoPilotJob("market_management").catch(err =>
      console.error("[AutoPilot] Scheduled run failed:", err)
    );
  }, intervalMs);

  console.log("[AutoPilot] Continuous scheduling initialized");
}

export default runAutoPilotJob;
