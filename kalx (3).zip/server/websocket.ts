import { Server as SocketIOServer, Socket } from "socket.io";
import { getDb } from "./db";
import { eq } from "drizzle-orm";
import { markets } from "../drizzle/schema";

interface PriceUpdate {
  marketId: number;
  yesPrice: number;
  noPrice: number;
  timestamp: number;
  volume: number;
}

interface TradeNotification {
  marketId: number;
  type: "BUY" | "SELL";
  outcome: string;
  shares: number;
  price: number;
  timestamp: number;
}

interface CommentNotification {
  marketId: number;
  userName: string;
  text: string;
  timestamp: number;
}

export function setupWebSocketHandlers(io: SocketIOServer) {
  // Track connected clients and their subscriptions
  const clientSubscriptions = new Map<string, Set<number>>();

  io.on("connection", (socket: Socket) => {
    console.log(`[WebSocket] Client connected: ${socket.id}`);
    clientSubscriptions.set(socket.id, new Set());

    // Subscribe to market updates
    socket.on("subscribe:market", (marketId: number) => {
      const subscriptions = clientSubscriptions.get(socket.id);
      if (subscriptions) {
        subscriptions.add(marketId);
        socket.join(`market:${marketId}`);
        console.log(`[WebSocket] Client ${socket.id} subscribed to market ${marketId}`);
      }
    });

    // Unsubscribe from market updates
    socket.on("unsubscribe:market", (marketId: number) => {
      const subscriptions = clientSubscriptions.get(socket.id);
      if (subscriptions) {
        subscriptions.delete(marketId);
        socket.leave(`market:${marketId}`);
        console.log(`[WebSocket] Client ${socket.id} unsubscribed from market ${marketId}`);
      }
    });

    // Subscribe to all markets
    socket.on("subscribe:all", () => {
      socket.join("markets:all");
      console.log(`[WebSocket] Client ${socket.id} subscribed to all markets`);
    });

    // Handle disconnection
    socket.on("disconnect", () => {
      clientSubscriptions.delete(socket.id);
      console.log(`[WebSocket] Client disconnected: ${socket.id}`);
    });
  });

  return {
    io,
    // Broadcast price update to subscribed clients
    broadcastPriceUpdate: (update: PriceUpdate) => {
      io.to(`market:${update.marketId}`).emit("price:update", update);
      io.to("markets:all").emit("price:update", update);
    },

    // Broadcast trade notification
    broadcastTrade: (notification: TradeNotification) => {
      io.to(`market:${notification.marketId}`).emit("trade:executed", notification);
      io.to("markets:all").emit("trade:executed", notification);
    },

    // Broadcast comment notification
    broadcastComment: (notification: CommentNotification) => {
      io.to(`market:${notification.marketId}`).emit("comment:new", notification);
    },

    // Broadcast leaderboard update
    broadcastLeaderboardUpdate: (leaderboard: any[]) => {
      io.emit("leaderboard:update", leaderboard);
    },

    // Broadcast market resolution
    broadcastMarketResolution: (marketId: number, resolvedOutcome: string) => {
      io.to(`market:${marketId}`).emit("market:resolved", {
        marketId,
        resolvedOutcome,
        timestamp: Date.now(),
      });
      io.to("markets:all").emit("market:resolved", {
        marketId,
        resolvedOutcome,
        timestamp: Date.now(),
      });
    },

    // Broadcast new market creation
    broadcastNewMarket: (market: any) => {
      io.emit("market:created", market);
    },
  };
}

/**
 * Simulate real-time price updates for demo purposes
 * In production, this would be triggered by actual trades
 */
export async function simulatePriceUpdates(
  io: SocketIOServer,
  interval: number = 5000
) {
  setInterval(async () => {
    try {
      const db = await getDb();
      if (!db) return;

      // Get all active markets
      const activeMarkets = await db
        .select()
        .from(markets)
        .limit(10);

      for (const market of activeMarkets) {
        // Simulate small price movements
        const shares = typeof market.shares === "string" ? JSON.parse(market.shares) : market.shares;
        const yesShares = (shares?.YES || 0) as number;
        const noShares = (shares?.NO || 0) as number;
        const total = yesShares + noShares || 1;

        const yesPrice = yesShares / total;
        const noPrice = noShares / total;

        // Add small random movement
        const movement = (Math.random() - 0.5) * 0.02;
        const newYesPrice = Math.max(0.01, Math.min(0.99, yesPrice + movement));
        const newNoPrice = 1 - newYesPrice;

        io.to(`market:${market.id}`).emit("price:update", {
          marketId: market.id,
          yesPrice: newYesPrice,
          noPrice: newNoPrice,
          timestamp: Date.now(),
          volume: typeof market.volume === 'number' ? market.volume : 0,
        });
      }
    } catch (error) {
      console.error("[WebSocket] Error simulating price updates:", error);
    }
  }, interval);
}
