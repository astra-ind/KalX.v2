import axios from "axios";

const NEWS_API_KEY = process.env.NEWS_API_KEY || "demo";
const NEWS_API_URL = "https://newsapi.org/v2";

export interface NewsArticle {
  title: string;
  description: string;
  source: string;
  url: string;
  publishedAt: string;
  category: string;
}

export interface TrendingTopic {
  title: string;
  description: string;
  category: string;
  source: string;
}

/**
 * Fetch trending news from NewsAPI
 * Falls back to mock data if API key is not configured
 */
export async function getTrendingTopics(): Promise<TrendingTopic[]> {
  try {
    if (NEWS_API_KEY === "demo") {
      console.log("[NewsService] Using mock trending topics (configure NEWS_API_KEY for real data)");
      return getMockTrendingTopics();
    }

    const topics: TrendingTopic[] = [];

    // Fetch from multiple categories
    const categories = ["business", "technology", "politics", "sports", "health"];

    for (const category of categories) {
      try {
        const response = await axios.get(`${NEWS_API_URL}/top-headlines`, {
          params: {
            category,
            language: "en",
            pageSize: 5,
            apiKey: NEWS_API_KEY,
          },
          timeout: 5000,
        });

        if (response.data.articles && response.data.articles.length > 0) {
          const article = response.data.articles[0];
          topics.push({
            title: article.title,
            description: article.description || article.content || "",
            category: mapCategory(category),
            source: article.source.name,
          });
        }
      } catch (error) {
        console.warn(`[NewsService] Failed to fetch ${category} news:`, error);
      }
    }

    if (topics.length === 0) {
      console.warn("[NewsService] No topics fetched from API, using mock data");
      return getMockTrendingTopics();
    }

    return topics;
  } catch (error) {
    console.error("[NewsService] Error fetching trending topics:", error);
    return getMockTrendingTopics();
  }
}

/**
 * Generate market title from news topic
 */
export function generateMarketTitle(topic: TrendingTopic): string {
  const titles = [
    `Will "${topic.title.substring(0, 50)}" impact the market by end of month?`,
    `Will this trend from ${topic.source} continue for another week?`,
    `Will the market react positively to: "${topic.title.substring(0, 40)}"?`,
    `Will ${topic.category} see significant changes due to recent news?`,
  ];

  return titles[Math.floor(Math.random() * titles.length)];
}

/**
 * Generate market description from news topic
 */
export function generateMarketDescription(topic: TrendingTopic): string {
  return `Based on recent news: ${topic.description || topic.title}. Source: ${topic.source}. This market will resolve based on verified reporting from major news outlets.`;
}

/**
 * Map news API categories to KalX categories
 */
function mapCategory(newsCategory: string): string {
  const categoryMap: Record<string, string> = {
    business: "Finance",
    technology: "Technology",
    politics: "Politics",
    sports: "Sports",
    health: "Finance",
    entertainment: "Entertainment",
    science: "Technology",
    general: "Other",
  };

  return categoryMap[newsCategory] || "Other";
}

/**
 * Mock trending topics for demo/fallback
 */
function getMockTrendingTopics(): TrendingTopic[] {
  return [
    {
      title: "Federal Reserve Signals Potential Rate Cut in Q3 2026",
      description:
        "The Federal Reserve Chair indicated in a recent speech that interest rate cuts could be on the table if inflation continues to cool.",
      category: "Finance",
      source: "Reuters",
    },
    {
      title: "Tech Giants Report Record Q2 Earnings",
      description:
        "Major technology companies beat earnings expectations, with AI investments driving growth across the sector.",
      category: "Technology",
      source: "Bloomberg",
    },
    {
      title: "Global Climate Summit Reaches Historic Agreement",
      description:
        "Nations worldwide agree on ambitious new climate targets, committing to carbon neutrality by 2050.",
      category: "Politics",
      source: "AP News",
    },
    {
      title: "Championship Team Wins Historic Victory",
      description:
        "Underdog team defeats defending champions in thrilling overtime match, securing their first title in 20 years.",
      category: "Sports",
      source: "ESPN",
    },
    {
      title: "Breakthrough in Quantum Computing Announced",
      description:
        "Researchers achieve major milestone in quantum computing, potentially revolutionizing data processing capabilities.",
      category: "Technology",
      source: "Science Daily",
    },
  ];
}
