/**
 * LMSR (Logarithmic Market Scoring Rule) AMM Implementation
 * 
 * The LMSR is a market maker algorithm that prices shares based on the
 * current quantity of shares outstanding. It provides automatic liquidity
 * and ensures the market remains solvent.
 * 
 * Key formula: Cost(q) = b * ln(sum(exp(q_i / b)))
 * where:
 *   - b is the liquidity parameter (higher = more liquidity, less price impact)
 *   - q_i is the quantity of shares for outcome i
 *   - ln is the natural logarithm
 *   - exp is the exponential function
 */

/**
 * Calculate the cost to buy shares using LMSR formula
 * @param quantities Current quantities of shares for each outcome
 * @param outcomeIndex Which outcome to buy shares of
 * @param sharesToBuy Number of shares to buy
 * @param liquidityParameter The liquidity parameter (b)
 * @returns Cost in tokens
 */
export function calculateCostLMSR(
  quantities: number[],
  outcomeIndex: number,
  sharesToBuy: number,
  liquidityParameter: number
): number {
  if (sharesToBuy <= 0) return 0;
  if (outcomeIndex < 0 || outcomeIndex >= quantities.length) {
    throw new Error("Invalid outcome index");
  }

  // Calculate cost before and after the trade
  const quantitiesBefore = [...quantities];
  const quantitiesAfter = [...quantities];
  quantitiesAfter[outcomeIndex] += sharesToBuy;

  const costBefore = costFunction(quantitiesBefore, liquidityParameter);
  const costAfter = costFunction(quantitiesAfter, liquidityParameter);

  return costAfter - costBefore;
}

/**
 * Calculate the proceeds from selling shares using LMSR formula
 * @param quantities Current quantities of shares for each outcome
 * @param outcomeIndex Which outcome to sell shares of
 * @param sharesToSell Number of shares to sell
 * @param liquidityParameter The liquidity parameter (b)
 * @returns Proceeds in tokens
 */
export function calculateProceedsLMSR(
  quantities: number[],
  outcomeIndex: number,
  sharesToSell: number,
  liquidityParameter: number
): number {
  if (sharesToSell <= 0) return 0;
  if (quantities[outcomeIndex] < sharesToSell) {
    throw new Error("Insufficient shares to sell");
  }

  // Proceeds = cost to buy those shares (reverse operation)
  const quantitiesBefore = [...quantities];
  const quantitiesAfter = [...quantities];
  quantitiesAfter[outcomeIndex] -= sharesToSell;

  const costBefore = costFunction(quantitiesBefore, liquidityParameter);
  const costAfter = costFunction(quantitiesAfter, liquidityParameter);

  return costBefore - costAfter;
}

/**
 * Core LMSR cost function: b * ln(sum(exp(q_i / b)))
 */
function costFunction(quantities: number[], liquidityParameter: number): number {
  const b = liquidityParameter;
  
  // Prevent overflow by using the log-sum-exp trick
  const maxQ = Math.max(...quantities);
  
  let sum = 0;
  for (const q of quantities) {
    sum += Math.exp((q - maxQ) / b);
  }
  
  return b * (Math.log(sum) + maxQ / b);
}

/**
 * Calculate the current probability of an outcome
 * For binary markets, this is the implied probability
 * @param quantities Current quantities of shares for each outcome
 * @param outcomeIndex Which outcome to calculate probability for
 * @param liquidityParameter The liquidity parameter (b)
 * @returns Probability between 0 and 1
 */
export function calculateProbabilityLMSR(
  quantities: number[],
  outcomeIndex: number,
  liquidityParameter: number
): number {
  const b = liquidityParameter;
  
  const maxQ = Math.max(...quantities);
  
  let sum = 0;
  for (const q of quantities) {
    sum += Math.exp((q - maxQ) / b);
  }
  
  const numerator = Math.exp((quantities[outcomeIndex] - maxQ) / b);
  return numerator / sum;
}

/**
 * Calculate the price per share (marginal price)
 * This is the derivative of the cost function with respect to quantity
 * @param quantities Current quantities of shares for each outcome
 * @param outcomeIndex Which outcome to get the price for
 * @param liquidityParameter The liquidity parameter (b)
 * @returns Price per share
 */
export function calculatePricePerShareLMSR(
  quantities: number[],
  outcomeIndex: number,
  liquidityParameter: number
): number {
  // The marginal price is the probability
  return calculateProbabilityLMSR(quantities, outcomeIndex, liquidityParameter);
}

/**
 * Initialize quantities for a new market
 * @param numOutcomes Number of outcomes in the market
 * @param initialQuantity Initial quantity for each outcome (default 0)
 * @returns Array of quantities
 */
export function initializeQuantities(numOutcomes: number, initialQuantity: number = 0): number[] {
  return Array(numOutcomes).fill(initialQuantity);
}

/**
 * Validate LMSR parameters
 */
export function validateLMSRParams(
  quantities: number[],
  liquidityParameter: number
): { valid: boolean; error?: string } {
  if (!Array.isArray(quantities) || quantities.length === 0) {
    return { valid: false, error: "Quantities must be a non-empty array" };
  }

  if (liquidityParameter <= 0) {
    return { valid: false, error: "Liquidity parameter must be positive" };
  }

  if (quantities.some(q => q < 0)) {
    return { valid: false, error: "Quantities cannot be negative" };
  }

  return { valid: true };
}

/**
 * Calculate the market maker's profit (or loss)
 * This is the difference between what was paid and the current cost
 * @param quantities Current quantities of shares for each outcome
 * @param liquidityParameter The liquidity parameter (b)
 * @returns Market maker's profit
 */
export function calculateMarketMakerProfit(
  quantities: number[],
  liquidityParameter: number
): number {
  // The market maker's profit is the current cost minus the initial cost
  // Initial cost is 0 (no shares outstanding)
  const initialCost = costFunction(Array(quantities.length).fill(0), liquidityParameter);
  const currentCost = costFunction(quantities, liquidityParameter);
  
  return currentCost - initialCost;
}
